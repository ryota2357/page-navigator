// page-navigator — bindings list & row.

const { useState: __bRows, useEffect: __bRowsE, useRef: __bRowsR, useMemo: __bRowsM } = React;

// Compute a Set of conflicting trigger-strings for the given bindings.
// A trigger is in conflict if more than one binding maps it to different actions.
function findConflicts(bindings) {
  const map = new Map(); // serialized trigger -> Set of bindingIds
  bindings.forEach((b) => {
    b.triggers.forEach((t) => {
      const k = serializeTrigger(t);
      if (!map.has(k)) map.set(k, new Set());
      map.get(k).add(b.id);
    });
  });
  const conflicts = new Set();
  for (const [k, ids] of map.entries()) {
    if (ids.size > 1) conflicts.add(k);
  }
  return conflicts;
}

function ConflictBanner({ count, onJump }) {
  if (!count) return null;
  return (
    <div className="alert danger" style={{ margin: '12px 28px 0' }}>
      <Icon name="warn" size={14} />
      <div style={{ flex: 1 }}>
        <b>{count} 件のキー競合</b>
        同じトリガーが複数のバインディングに割り当てられています。保存時に確認します。
      </div>
      <button className="tbtn ghost" onClick={onJump}
              style={{ height: 24, padding: '0 8px', fontSize: 11.5 }}>
        最初の競合へ
      </button>
    </div>
  );
}

// One option-input row inside an editing binding.
function OptionField({ schema, value, onChange }) {
  const v = value === undefined ? schema.default : value;
  if (schema.type === 'number') {
    return (
      <div className="opt-row">
        <span className="opt-label">{schema.key}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <input className="opt-input" type="number"
                 value={v} step="1"
                 onChange={(e) => onChange(Number(e.target.value))} />
          {schema.unit && <span className="muted code" style={{ fontSize: 11 }}>{schema.unit}</span>}
        </div>
      </div>
    );
  }
  if (schema.type === 'boolean') {
    return (
      <div className="opt-row">
        <span className="opt-label">{schema.key}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button className="opt-toggle" data-on={String(!!v)}
                  onClick={() => onChange(!v)}><i /></button>
          <span className="muted code" style={{ fontSize: 11 }}>{v ? 'true' : 'false'}</span>
        </div>
      </div>
    );
  }
  if (schema.type === 'select') {
    return (
      <div className="opt-row">
        <span className="opt-label">{schema.key}</span>
        <select className="opt-select" value={v}
                onChange={(e) => onChange(e.target.value)}>
          {schema.choices.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
    );
  }
  return (
    <div className="opt-row">
      <span className="opt-label">{schema.key}</span>
      <input className="opt-input" type="text" value={v || ''}
             placeholder="(empty)"
             onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

// Compact options summary (read-only row).
function OptionsSummary({ action, opts }) {
  if (!action || action.opts.length === 0) {
    return <span className="muted code" style={{ fontSize: 11 }}>—</span>;
  }
  return (
    <>
      {action.opts.map((schema) => {
        const val = opts[schema.key] === undefined ? schema.default : opts[schema.key];
        return (
          <span key={schema.key} className="opt-pill">
            <span className="opt-key">{schema.key}</span>
            {schema.type === 'boolean'
              ? <span className="opt-bool" data-on={String(!!val)}>
                  <span className="opt-val">{val ? 'on' : 'off'}</span>
                </span>
              : <>
                  <span className="opt-val">{String(val)}</span>
                  {schema.unit && <span className="opt-key">{schema.unit}</span>}
                </>
            }
          </span>
        );
      })}
    </>
  );
}

// One binding row.
function BindingRow({ binding, scope, conflictKeys, editing, picker,
                      onStartEdit, onCommitEdit, onCancelEdit, onDelete,
                      onChange, onOpenPicker, onClosePicker, pickerVariant }) {
  const action = ACTIONS.find((a) => a.id === binding.action);
  const rowRef = __bRowsR(null);
  const actionRef = __bRowsR(null);

  const isConflict = binding.triggers.some((t) => conflictKeys.has(serializeTrigger(t)));
  const [capturing, setCapturing] = __bRows(false);

  __bRowsE(() => {
    if (!editing || !capturing) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') { setCapturing(false); return; }
      // Capture key — single-key binding for the prototype.
      e.preventDefault();
      const k = e.key;
      const triggers = [...binding.triggers, [k]];
      onChange({ ...binding, triggers });
      setCapturing(false);
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [editing, capturing, binding, onChange]);

  const removeTrigger = (i) => {
    const triggers = binding.triggers.filter((_, j) => j !== i);
    onChange({ ...binding, triggers });
  };

  const onPickAction = (a) => {
    // Reset opts to action's defaults.
    const defaults = {};
    a.opts.forEach((o) => { defaults[o.key] = o.default; });
    onChange({ ...binding, action: a.id, opts: defaults });
    onClosePicker();
  };

  return (
    <div ref={rowRef}
         className={'brow' + (editing ? ' editing' : '') + (isConflict ? ' conflict' : '')}
         data-binding-id={binding.id}
         onClick={() => !editing && onStartEdit()}>
      <TriggerCell triggers={binding.triggers}
                   conflictKeys={conflictKeys}
                   editing={editing}
                   capturing={capturing}
                   onAdd={() => setCapturing(true)}
                   onCancelCapture={() => setCapturing(false)}
                   onRemove={removeTrigger} />

      <div className="cell-action">
        {editing ? (
          <div ref={actionRef} className="action-picker-trigger"
               onClick={(e) => { e.stopPropagation(); onOpenPicker(actionRef); }}>
            {action ? (
              <>
                <span className="action-name">{action.name}</span>
                {action.site && (() => {
                  const sites = Array.isArray(action.site) ? action.site : [action.site];
                  return (
                    <span className="badge site">
                      {sites.length === 1 && (
                        <SiteFav service={SERVICES.find((s) => s.id === sites[0])} size={10} />
                      )}
                      {sites.map((id) => SERVICES.find((s) => s.id === id).name).join(' / ')}
                    </span>
                  );
                })()}
              </>
            ) : <span className="muted">Pick an action…</span>}
            <span className="chev"><Icon name="down" size={10} /></span>
          </div>
        ) : (
          <>
            <span className="action-name">
              {action ? action.name : <span className="muted">unset</span>}
              {action?.site && (() => {
                const sites = Array.isArray(action.site) ? action.site : [action.site];
                return (
                  <span className="badge site">
                    {sites.length === 1 && (
                      <SiteFav service={SERVICES.find((s) => s.id === sites[0])} size={10} />
                    )}
                    {sites.map((id) => SERVICES.find((s) => s.id === id).name).join(' / ')}
                  </span>
                );
              })()}
            </span>
            <span className="action-desc">{action?.desc}</span>
          </>
        )}

        {/* Inline picker pop-over rendered as a sibling, not a parent of click target */}
        {editing && picker?.bindingId === binding.id && pickerVariant === 'inline' && (
          <ActionPickerInline scope={scope}
                              anchor={picker.anchor}
                              onClose={onClosePicker}
                              onPick={onPickAction} />
        )}
      </div>

      <div className="cell-options">
        {editing ? (
          action?.opts.length ? action.opts.map((schema) => (
            <OptionField key={schema.key}
                         schema={schema}
                         value={binding.opts[schema.key]}
                         onChange={(val) => onChange({
                           ...binding, opts: { ...binding.opts, [schema.key]: val }
                         })} />
          )) : <span className="muted code" style={{ fontSize: 11 }}>このアクションに設定項目はありません</span>
        ) : (
          <OptionsSummary action={action} opts={binding.opts} />
        )}
      </div>

      <button className="brow-menu" title="More"
              onClick={(e) => { e.stopPropagation(); onDelete(); }}>
        <Icon name="trash" size={13} />
      </button>

      {isConflict && !editing && (
        <div className="row-warn">
          <Icon name="warn" size={12} />
          このトリガーは同スコープ内で別のバインディングと競合しています。
        </div>
      )}

      {editing && (
        <div className="brow-edit-actions">
          <button className="tbtn ghost" onClick={(e) => { e.stopPropagation(); onDelete(); }}>
            <Icon name="trash" size={12} /> 削除
          </button>
          <span className="spacer" />
          <button className="tbtn ghost" onClick={(e) => { e.stopPropagation(); onCancelEdit(); }}>
            キャンセル
          </button>
          <button className="tbtn primary" onClick={(e) => { e.stopPropagation(); onCommitEdit(); }}>
            完了 <Kbd>↵</Kbd>
          </button>
        </div>
      )}
    </div>
  );
}

// Group bindings by category (of their action) for visual rhythm.
function groupBindingsByCategory(bindings) {
  const groups = {};
  bindings.forEach((b) => {
    const a = ACTIONS.find((x) => x.id === b.action);
    const cat = a?.cat || 'unset';
    (groups[cat] ||= []).push(b);
  });
  return groups;
}

function BindingsList({ bindings, scope, editingId, picker, pickerVariant,
                        onStartEdit, onCommitEdit, onCancelEdit, onDelete,
                        onChange, onAdd, onOpenPicker, onClosePicker, query }) {
  const conflictKeys = __bRowsM(() => findConflicts(bindings), [bindings]);
  const filtered = __bRowsM(() => {
    if (!query) return bindings;
    const q = query.toLowerCase();
    return bindings.filter((b) => {
      const a = ACTIONS.find((x) => x.id === b.action);
      const triggerText = b.triggers.map(serializeTrigger).join(' ').toLowerCase();
      return (a?.name.toLowerCase().includes(q) ||
              a?.desc.toLowerCase().includes(q) ||
              triggerText.includes(q));
    });
  }, [bindings, query]);

  return (
    <div className="bindings">
      <div className="bindings-header">
        <div>Trigger</div>
        <div>Action</div>
        <div>Options</div>
        <div></div>
      </div>
      {filtered.map((b) => (
        <BindingRow key={b.id}
                    binding={b}
                    scope={scope}
                    conflictKeys={conflictKeys}
                    editing={editingId === b.id}
                    picker={picker}
                    pickerVariant={pickerVariant}
                    onStartEdit={() => onStartEdit(b.id)}
                    onCommitEdit={onCommitEdit}
                    onCancelEdit={onCancelEdit}
                    onDelete={() => onDelete(b.id)}
                    onChange={(nb) => onChange(nb)}
                    onOpenPicker={(ref) => onOpenPicker(b.id, ref)}
                    onClosePicker={onClosePicker} />
      ))}
      <button className="add-row" onClick={onAdd}
              style={{ marginTop: 18, border: '1px dashed var(--border-strong)',
                       borderRadius: 'var(--r-md)', justifyContent: 'center' }}>
        <Icon name="plus" size={14} /> 新しいバインディングを追加
      </button>
    </div>
  );
}

Object.assign(window, { BindingsList, ConflictBanner, findConflicts });
