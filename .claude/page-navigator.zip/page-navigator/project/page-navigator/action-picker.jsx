// page-navigator — Action picker (3 variations).
// Variation switches via Tweaks: 'inline' | 'modal' | 'palette'.

const { useState: __apState, useEffect: __apEff, useRef: __apRef, useMemo: __apMemo } = React;

// Filter ACTIONS by query (substring fuzzy-ish), grouped by category.
function filterActions(query, scope) {
  const q = (query || '').toLowerCase().trim();
  // Globals can't pick site-specific actions; site scopes can pick global + their site's.
  const inScope = ACTIONS.filter((a) => {
    if (!a.site) return true;
    if (scope === 'global') return false;
    const sites = Array.isArray(a.site) ? a.site : [a.site];
    return sites.includes(scope);
  });
  const matches = !q ? inScope : inScope.filter((a) => {
    return a.name.toLowerCase().includes(q)
        || a.desc.toLowerCase().includes(q)
        || a.cat.toLowerCase().includes(q);
  });
  // Group
  const groups = {};
  matches.forEach((a) => { (groups[a.cat] ||= []).push(a); });
  return { groups, total: matches.length };
}

function ActionPickerList({ groups, focusIdx, onPick, onHover }) {
  // Flatten with category headers for keyboard navigation.
  let flatIdx = -1;
  return (
    <div className="picker-list">
      {CATEGORIES.map((cat) => {
        const items = groups[cat.id];
        if (!items || items.length === 0) return null;
        return (
          <div key={cat.id}>
            <div className="picker-group">{cat.label}</div>
            {items.map((a) => {
              flatIdx++;
              const isFocused = flatIdx === focusIdx;
              return (
                <div key={a.id}
                     className={'picker-item' + (isFocused ? ' focused' : '')}
                     onMouseMove={() => onHover?.(flatIdx)}
                     onClick={() => onPick(a)}>
                  <div className="pi-name">
                    {a.name}
                    {a.site && (() => {
                      const sites = Array.isArray(a.site) ? a.site : [a.site];
                      const label = sites.length === 1
                        ? SERVICES.find((s) => s.id === sites[0]).name
                        : sites.map((id) => SERVICES.find((s) => s.id === id).name).join(' / ');
                      return (
                        <span className="badge site">
                          {sites.length === 1 && (
                            <SiteFav service={SERVICES.find((s) => s.id === sites[0])} size={10} />
                          )}
                          {label}
                        </span>
                      );
                    })()}
                  </div>
                  <div className="pi-desc">{a.desc}</div>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

// Inline dropdown (default). Anchored to the row, opens below the action cell.
function ActionPickerInline({ scope, anchor, onClose, onPick }) {
  const [q, setQ] = __apState('');
  const [focus, setFocus] = __apState(0);
  const inp = __apRef(null);
  __apEff(() => { inp.current?.focus(); }, []);

  const { groups, total } = filterActions(q, scope);
  const flat = useFlatList(groups);

  __apEff(() => { setFocus(0); }, [q]);

  const onKey = (e) => {
    if (e.key === 'ArrowDown') { setFocus((i) => Math.min(flat.length - 1, i + 1)); e.preventDefault(); }
    else if (e.key === 'ArrowUp')   { setFocus((i) => Math.max(0, i - 1)); e.preventDefault(); }
    else if (e.key === 'Enter') { if (flat[focus]) onPick(flat[focus]); e.preventDefault(); }
    else if (e.key === 'Escape') { onClose(); }
  };

  const style = anchor
    ? { left: anchor.left, top: anchor.top, width: anchor.width }
    : {};

  return (
    <div className="picker-pop" style={style}
         onClick={(e) => e.stopPropagation()}>
      <div className="picker-search">
        <Icon name="search" size={14} />
        <input ref={inp} value={q}
               onChange={(e) => setQ(e.target.value)}
               onKeyDown={onKey}
               placeholder={`Search ${scope === 'global' ? 'global' : 'global + site'} actions…`} />
        <Kbd>esc</Kbd>
      </div>
      <ActionPickerList groups={groups} focusIdx={focus}
                        onPick={onPick} onHover={setFocus} />
      <div className="picker-foot">
        <span className="hint"><Kbd>↑</Kbd><Kbd>↓</Kbd><span>navigate</span></span>
        <span className="hint"><Kbd>↵</Kbd><span>select</span></span>
        <span className="hint"><Kbd>esc</Kbd><span>close</span></span>
        <a href="#docs" onClick={(e) => e.preventDefault()}>
          docs <Icon name="export" size={11} />
        </a>
      </div>
    </div>
  );
}

// Modal variation — opens centered. Larger reading surface, options shown
// once an action is hovered/selected.
function ActionPickerModal({ scope, currentValue, onClose, onPick }) {
  const [q, setQ] = __apState('');
  const [focus, setFocus] = __apState(0);
  const { groups } = filterActions(q, scope);
  const flat = useFlatList(groups);
  const focused = flat[focus];

  __apEff(() => { setFocus(0); }, [q]);

  const onKey = (e) => {
    if (e.key === 'ArrowDown') { setFocus((i) => Math.min(flat.length - 1, i + 1)); e.preventDefault(); }
    else if (e.key === 'ArrowUp')   { setFocus((i) => Math.max(0, i - 1)); e.preventDefault(); }
    else if (e.key === 'Enter') { if (focused) onPick(focused); e.preventDefault(); }
    else if (e.key === 'Escape') { onClose(); }
  };

  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal lg" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          <div>
            <div className="ttl">Pick an action</div>
            <div className="sub">
              {scope === 'global'
                ? 'Global actions only'
                : `Global + ${SERVICES.find(s => s.id === scope)?.name}-specific actions`}
            </div>
          </div>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', minHeight: 0, flex: 1 }}>
          <div style={{ display: 'flex', flexDirection: 'column', minHeight: 0, borderRight: '1px solid var(--border)' }}>
            <div className="picker-search">
              <Icon name="search" size={14} />
              <input autoFocus value={q}
                     onChange={(e) => setQ(e.target.value)}
                     onKeyDown={onKey}
                     placeholder="Search actions by name, description, or category…" />
            </div>
            <div style={{ flex: 1, overflowY: 'auto' }}>
              <ActionPickerList groups={groups} focusIdx={focus}
                                onPick={onPick} onHover={setFocus} />
            </div>
          </div>
          <div style={{ padding: 16, fontSize: 12, lineHeight: 1.55, overflowY: 'auto', background: 'var(--canvas)' }}>
            {focused ? (
              <>
                <div className="code" style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
                  {focused.name}
                </div>
                {focused.site && (() => {
                  const sites = Array.isArray(focused.site) ? focused.site : [focused.site];
                  return (
                    <span className="badge site" style={{ marginBottom: 8, display: 'inline-flex' }}>
                      Only on {sites.map((id) => SERVICES.find((s) => s.id === id).name).join(' / ')}
                    </span>
                  );
                })()}
                <p style={{ margin: '8px 0 12px', color: 'var(--text-2)' }}>{focused.desc}</p>
                {focused.opts.length > 0 ? (
                  <>
                    <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '.1em',
                                  color: 'var(--text-3)', fontWeight: 600, marginBottom: 6 }}>
                      Options
                    </div>
                    {focused.opts.map((o) => (
                      <div key={o.key} className="code" style={{ fontSize: 11.5, padding: '3px 0', color: 'var(--text-2)' }}>
                        <span style={{ color: 'var(--text-1)' }}>{o.key}</span>
                        <span style={{ color: 'var(--text-3)' }}>: {o.type}</span>
                        <span style={{ marginLeft: 6, color: 'var(--text-3)' }}>= {String(o.default)}</span>
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="muted" style={{ fontSize: 11.5 }}>(no options)</div>
                )}
                <a href="#docs" onClick={(e) => e.preventDefault()}
                   style={{ color: 'var(--text-1)', display: 'inline-flex', gap: 4,
                            alignItems: 'center', marginTop: 16, textDecoration: 'none',
                            fontSize: 11.5 }}>
                  Read full docs <Icon name="export" size={11} />
                </a>
              </>
            ) : (
              <div className="muted" style={{ fontSize: 11.5 }}>No matches.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Command palette — full-window overlay, ⌘K-style.
function ActionPickerPalette({ scope, onClose, onPick }) {
  const [q, setQ] = __apState('');
  const [focus, setFocus] = __apState(0);
  const { groups } = filterActions(q, scope);
  const flat = useFlatList(groups);
  __apEff(() => setFocus(0), [q]);

  const onKey = (e) => {
    if (e.key === 'ArrowDown') { setFocus((i) => Math.min(flat.length - 1, i + 1)); e.preventDefault(); }
    else if (e.key === 'ArrowUp')   { setFocus((i) => Math.max(0, i - 1)); e.preventDefault(); }
    else if (e.key === 'Enter') { if (flat[focus]) onPick(flat[focus]); e.preventDefault(); }
    else if (e.key === 'Escape') { onClose(); }
  };

  const scopeName = scope === 'global'
    ? 'Global'
    : SERVICES.find((s) => s.id === scope)?.name;

  return (
    <div className="palette-scrim" onClick={onClose}>
      <div className="palette" onClick={(e) => e.stopPropagation()}>
        <div className="palette-search">
          <Icon name="search" size={16} />
          <span className="ctx">{scopeName}</span>
          <input autoFocus value={q}
                 onChange={(e) => setQ(e.target.value)}
                 onKeyDown={onKey}
                 placeholder="Type an action name or description…" />
          <Kbd>esc</Kbd>
        </div>
        <ActionPickerList groups={groups} focusIdx={focus}
                          onPick={onPick} onHover={setFocus} />
        <div className="picker-foot">
          <span className="hint"><Kbd>↑</Kbd><Kbd>↓</Kbd><span>navigate</span></span>
          <span className="hint"><Kbd>↵</Kbd><span>select</span></span>
          <span className="hint"><Kbd>esc</Kbd><span>close</span></span>
        </div>
      </div>
    </div>
  );
}

function useFlatList(groups) {
  return __apMemo(() => {
    const flat = [];
    CATEGORIES.forEach((cat) => { (groups[cat.id] || []).forEach((a) => flat.push(a)); });
    return flat;
  }, [groups]);
}

Object.assign(window, { ActionPickerInline, ActionPickerModal, ActionPickerPalette });
