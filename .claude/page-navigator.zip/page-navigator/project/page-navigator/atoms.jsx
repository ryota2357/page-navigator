// page-navigator — small UI atoms shared across the app.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// Format a single trigger combo (an array of key tokens like ['Shift','j'])
// into a sequence of <kbd> tags, joined with a "+" between modifier+key
// and a space between sequence steps (vim-style multi-key).
function TriggerKeyTag({ combo, conflict, removable, onRemove }) {
  // Combo is just one key for now (no modifiers in this prototype, since the
  // requirements explicitly allow single-key bindings). For multi-step
  // sequences, the binding stores them as separate combos in `triggers`.
  const label = displayKey(combo[0]);
  return (
    <span className={'tkey' + (conflict ? ' conflict' : '')}>
      <span className="tkey-piece">{label}</span>
      {removable && (
        <button className="tkey-x" onClick={(e) => { e.stopPropagation(); onRemove?.(); }}
                aria-label={`Remove ${label}`}>×</button>
      )}
    </span>
  );
}

// Render the full trigger column: each entry in `triggers` is either a single
// key combo OR a sequence (e.g. ['g','g']). Sequences render as adjacent kbd
// tags inside one tag wrapper, separated by a thin gap.
function TriggerCell({ triggers, conflictKeys, editing, onAdd, onRemove, capturing, onCancelCapture }) {
  return (
    <div className="cell-trigger">
      {triggers.map((seq, i) => {
        const isConflict = conflictKeys?.has(serializeTrigger(seq));
        return (
          <span key={i} className={'tkey' + (isConflict ? ' conflict' : '') + (seq.length > 1 ? ' compound' : '')}>
            {seq.map((k, j) => (
              <React.Fragment key={j}>
                {j > 0 && <span className="tkey-plus" aria-hidden>·</span>}
                <span className="tkey-piece">{displayKey(k)}</span>
              </React.Fragment>
            ))}
            {editing && (
              <button className="tkey-x" onClick={(e) => { e.stopPropagation(); onRemove?.(i); }}
                      aria-label="Remove trigger">×</button>
            )}
          </span>
        );
      })}
      {editing && capturing && (
        <span className="tkey-capture">
          <span className="pulse" />
          press a key…
          <button className="tkey-x" onClick={onCancelCapture} aria-label="Cancel capture">×</button>
        </span>
      )}
      {editing && !capturing && (
        <button className="tkey-add" onClick={onAdd} title="Add trigger key">
          + add key
        </button>
      )}
    </div>
  );
}

function displayKey(k) {
  if (k === ' ') return 'Space';
  if (k === 'ArrowLeft') return '←';
  if (k === 'ArrowRight') return '→';
  if (k === 'ArrowUp') return '↑';
  if (k === 'ArrowDown') return '↓';
  if (k === 'Enter') return '↵';
  if (k === 'Escape') return 'Esc';
  if (k === 'Tab') return '⇥';
  return k;
}

function serializeTrigger(seq) {
  return seq.join(' ');
}

function Kbd({ children }) { return <span className="kbd">{children}</span>; }

// Site favicon-ish square. Uses each service's color + initial, no real logos.
function SiteFav({ service, size }) {
  const s = size || 16;
  return (
    <span className="side-fav" style={{
      background: service.color,
      width: s, height: s,
      fontSize: s <= 16 ? 9 : 10,
    }}>{service.initials}</span>
  );
}

function Icon({ name, size = 14 }) {
  const s = size;
  const stroke = 'currentColor';
  const sw = 1.5;
  switch (name) {
    case 'globe': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6" stroke={stroke} strokeWidth={sw} />
        <path d="M2 8h12M8 2c2 1.8 3 4 3 6s-1 4.2-3 6c-2-1.8-3-4-3-6s1-4.2 3-6Z" stroke={stroke} strokeWidth={sw} />
      </svg>
    );
    case 'search': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <circle cx="7" cy="7" r="4.5" stroke={stroke} strokeWidth={sw} />
        <path d="m10.5 10.5 3 3" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'plus': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M8 3v10M3 8h10" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'sliders': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M3 4h7M13 4h0M3 12h2M8 12h5" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
        <circle cx="11.5" cy="4" r="1.5" stroke={stroke} strokeWidth={sw} />
        <circle cx="6.5"  cy="12" r="1.5" stroke={stroke} strokeWidth={sw} />
      </svg>
    );
    case 'book': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M3 3h6a2 2 0 0 1 2 2v8M3 3v8a2 2 0 0 0 2 2h6M3 3a1 1 0 0 0 0 2h6" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    case 'down': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="m4 6 4 4 4-4" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    case 'dots': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor">
        <circle cx="3.5" cy="8" r="1.2" /><circle cx="8" cy="8" r="1.2" /><circle cx="12.5" cy="8" r="1.2" />
      </svg>
    );
    case 'export': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M8 10V3M5 6l3-3 3 3M3 11v1a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    case 'import': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M8 3v7M5 7l3 3 3-3M3 11v1a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    case 'warn': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M8 2 1.5 13.5h13L8 2Z" stroke={stroke} strokeWidth={sw} strokeLinejoin="round" />
        <path d="M8 6.5v3.5M8 12v.01" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'trash': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M3 4.5h10M5.5 4.5V3a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1.5M4 4.5v8.5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.5M7 7v4M9 7v4" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'copy': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <rect x="5" y="5" width="8" height="8" rx="1.5" stroke={stroke} strokeWidth={sw} />
        <path d="M3 10V4a1 1 0 0 1 1-1h6" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'check': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="m3 8.5 3 3 7-7" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    case 'gear': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="2" stroke={stroke} strokeWidth={sw} />
        <path d="M8 2v1.6M8 12.4V14M2 8h1.6M12.4 8H14M3.8 3.8l1.1 1.1M11.1 11.1l1.1 1.1M3.8 12.2l1.1-1.1M11.1 4.9l1.1-1.1" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
      </svg>
    );
    case 'enter': return (
      <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
        <path d="M13 4v3a2 2 0 0 1-2 2H4M7 6 4 9l3 3" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
    default: return null;
  }
}

Object.assign(window, {
  TriggerKeyTag, TriggerCell, displayKey, serializeTrigger,
  Kbd, SiteFav, Icon,
});
