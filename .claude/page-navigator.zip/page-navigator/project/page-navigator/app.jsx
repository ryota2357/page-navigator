// page-navigator — root app component.
// Wires together sidebar + main view (bindings list / reference) + modals + tweaks.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "pickerVariant": "modal",
  "density": "compact",
  "showSiteCatalog": "configured-only",
  "accent": "neutral"
}/*EDITMODE-END*/;

const SCOPE_LABELS = {
  global: 'Global',
};
SERVICES.forEach((s) => { SCOPE_LABELS[s.id] = s.name; });

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Density tweak: tweak the row vertical padding.
  useEffect(() => {
    const r = document.documentElement;
    if (t.density === 'compact') r.style.setProperty('--side-w', '224px');
    else r.style.setProperty('--side-w', '240px');
  }, [t.density]);

  // Accent tweak
  useEffect(() => {
    const r = document.documentElement;
    if (t.accent === 'indigo') {
      r.style.setProperty('--accent', '#3b3a8c');
    } else if (t.accent === 'green') {
      r.style.setProperty('--accent', '#1f5b39');
    } else {
      r.style.setProperty('--accent', '#1a1815');
    }
  }, [t.accent]);

  // ─── State ───
  const [scope, setScope] = useState('global');     // 'global' | site id
  const [view, setView] = useState('edit');          // 'edit' | 'reference'
  const [bindings, setBindings] = useState(initialBindings);
  const [editingId, setEditingId] = useState(null);
  const [picker, setPicker] = useState(null); // {bindingId, anchor: {left, top, width}}
  const [showSave, setShowSave] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [query, setQuery] = useState('');
  const [savedToast, setSavedToast] = useState(false);

  // Configured sites = sites with at least one binding (for sidebar visibility).
  const configuredSites = useMemo(() => {
    const s = new Set();
    SERVICES.forEach((svc) => {
      if ((bindings[svc.id] || []).length > 0) s.add(svc.id);
    });
    if (t.showSiteCatalog === 'all') SERVICES.forEach((svc) => s.add(svc.id));
    return s;
  }, [bindings, t.showSiteCatalog]);

  const currentBindings = bindings[scope] || [];
  const conflictKeys = useMemo(() => findConflicts(currentBindings), [currentBindings]);

  // Counts for sidebar badges
  const bindingCounts = useMemo(() => {
    const o = { global: bindings.global?.length || 0 };
    SERVICES.forEach((s) => o[s.id] = bindings[s.id]?.length || 0);
    return o;
  }, [bindings]);

  const conflictCounts = useMemo(() => {
    const o = { global: findConflicts(bindings.global || []).size };
    SERVICES.forEach((s) => o[s.id] = findConflicts(bindings[s.id] || []).size);
    return o;
  }, [bindings]);

  // ─── Bindings mutations ───
  const updateBinding = (b) => setBindings((all) => ({
    ...all,
    [scope]: (all[scope] || []).map((x) => x.id === b.id ? b : x),
  }));
  const deleteBinding = (id) => {
    setBindings((all) => ({
      ...all,
      [scope]: (all[scope] || []).filter((x) => x.id !== id),
    }));
    if (editingId === id) setEditingId(null);
  };
  const addBinding = () => {
    const id = 'b' + Math.random().toString(36).slice(2, 8);
    const newB = { id, triggers: [], action: '', opts: {} };
    setBindings((all) => ({ ...all, [scope]: [...(all[scope] || []), newB] }));
    setEditingId(id);
  };
  const startEdit = (id) => setEditingId(id);
  const commitEdit = () => { setEditingId(null); setPicker(null); };
  const cancelEdit = () => { setEditingId(null); setPicker(null); };

  // Picker open/close
  const openPicker = (bindingId, ref) => {
    if (!ref?.current) { setPicker({ bindingId }); return; }
    const r = ref.current.getBoundingClientRect();
    if (t.pickerVariant === 'inline') {
      setPicker({
        bindingId,
        anchor: {
          left: r.left + window.scrollX,
          top: r.bottom + window.scrollY + 4,
          width: Math.max(r.width, 480),
        },
      });
    } else {
      setPicker({ bindingId });
    }
  };
  const closePicker = () => setPicker(null);

  // Apply preset (mock — clones from initialBindings or generates synthetic).
  const applyPreset = (preset) => {
    // Mock — just dump scrolling+nav bindings as a "vim-like" sample.
    const synth = preset.id === 'vim-like' ? initialBindings.global.slice(0, preset.bindingCount)
                  : preset.id === 'arrows' ? [
                      { id: 'p1', triggers: [['ArrowDown']], action: 'scrollDown', opts: { amount: 100 } },
                      { id: 'p2', triggers: [['ArrowUp']], action: 'scrollUp', opts: { amount: 100 } },
                      { id: 'p3', triggers: [['ArrowLeft']], action: 'goBack', opts: {} },
                      { id: 'p4', triggers: [['ArrowRight']], action: 'goForward', opts: {} },
                      { id: 'p5', triggers: [['Escape']], action: 'blurFocus', opts: {} },
                      { id: 'p6', triggers: [[' ']], action: 'scrollPageDown', opts: { overlap: 40 } },
                    ]
                  : initialBindings.global.slice(0, preset.bindingCount);
    setBindings((all) => ({ ...all, [scope]: synth }));
  };

  // Save flow
  const onSaveClick = () => {
    setShowSave(true);
  };
  const performSave = () => {
    setShowSave(false);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 1600);
  };

  // ESC closes editing/picker
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      if (picker) { setPicker(null); return; }
      if (showSave) { setShowSave(false); return; }
      if (showImport) { setShowImport(false); return; }
      if (showExport) { setShowExport(false); return; }
      if (editingId) { setEditingId(null); return; }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [editingId, picker, showSave, showImport, showExport]);

  // Scope label / badge in toolbar
  const scopeLabel = SCOPE_LABELS[scope];
  const scopeService = SERVICES.find((s) => s.id === scope);
  const isEmpty = currentBindings.length === 0;

  return (
    <div className="app" data-screen-label={view === 'reference' ? 'Reference' : `${scopeLabel} bindings`}>
      <Sidebar
        scope={scope} setScope={setScope}
        view={view} setView={setView}
        bindingCounts={bindingCounts}
        conflictCounts={conflictCounts}
        configuredSites={configuredSites}
        onAddSite={(id) => {
          setBindings((all) => ({ ...all, [id]: all[id]?.length ? all[id] : [] }));
          // Force the side item to appear by adding an empty placeholder isn't enough
          // since we use length>0 — instead we just navigate, and empty state shows.
          setScope(id); setView('edit');
          // Mark via tweak override:
          // (in real product we'd track configured sites separately from binding count)
        }}
        onShowImport={() => setShowImport(true)}
        onShowExport={() => setShowExport(true)}
        onShowReference={() => setView('reference')}
      />

      <div className="main">
        {/* Toolbar */}
        <div className="toolbar">
          <div className="crumb">
            {view === 'reference' ? (
              <>
                <Icon name="book" /> <span>Reference</span>
              </>
            ) : scopeService ? (
              <>
                <SiteFav service={scopeService} size={18} />
                <span>Site</span>
                <span className="sep">/</span>
                <span style={{ color: 'var(--text-1)', fontWeight: 500 }}>{scopeService.name}</span>
              </>
            ) : (
              <>
                <Icon name="globe" />
                <span style={{ color: 'var(--text-1)', fontWeight: 500 }}>Global</span>
              </>
            )}
          </div>

          <div className="toolbar-actions">
            {view === 'edit' && !isEmpty && (
              <>
                <button className="tbtn ghost" onClick={() => setView('reference')} title="このサイトのキーマップ一覧">
                  <Icon name="book" size={13} /> Reference
                </button>
                <button className="tbtn" onClick={addBinding}>
                  <Icon name="plus" size={13} /> 新規 <Kbd>N</Kbd>
                </button>
                <button className="tbtn primary" onClick={onSaveClick}
                        disabled={!hasUnsavedChanges()}>
                  保存 <Kbd>⌘ S</Kbd>
                </button>
              </>
            )}
            {view === 'reference' && (
              <button className="tbtn ghost" onClick={() => setView('edit')}>
                ← 編集に戻る
              </button>
            )}
          </div>
        </div>

        {/* Title row */}
        {view === 'edit' && !isEmpty && (
          <>
            <div style={{ padding: '20px 28px 0' }}>
              <div className="h-title">
                {scope === 'global' ? 'Global バインディング' : `${scopeLabel} バインディング`}
              </div>
              <div className="h-subtitle">
                {scope === 'global'
                  ? 'すべてのページで有効です。サイト固有の設定があれば、そちらが優先されます。'
                  : `${scopeLabel} のページ (${scopeService?.domain}) でのみ有効。Global を上書きします。`}
              </div>
            </div>
            {conflictKeys.size > 0 && (
              <ConflictBanner count={conflictKeys.size} onJump={() => {
                const first = currentBindings.find((b) =>
                  b.triggers.some((t) => conflictKeys.has(serializeTrigger(t))));
                if (first) {
                  setEditingId(first.id);
                  const el = document.querySelector(`[data-binding-id="${first.id}"]`);
                  el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
                }
              }} />
            )}
            <div className="list-toolbar">
              <div className="search-input">
                <Icon name="search" size={14} />
                <input value={query} onChange={(e) => setQuery(e.target.value)}
                       placeholder="トリガーやアクション名で絞り込み…" />
                <Kbd>/</Kbd>
              </div>
              <div className="muted" style={{ fontSize: 11.5 }}>
                {currentBindings.length} bindings
                {conflictKeys.size > 0 && (
                  <> · <span style={{ color: 'var(--danger)' }}>{conflictKeys.size} 競合</span></>
                )}
              </div>
            </div>
            <BindingsList
              bindings={currentBindings}
              scope={scope}
              editingId={editingId}
              picker={picker}
              pickerVariant={t.pickerVariant}
              query={query}
              onStartEdit={startEdit}
              onCommitEdit={commitEdit}
              onCancelEdit={cancelEdit}
              onDelete={deleteBinding}
              onChange={updateBinding}
              onAdd={addBinding}
              onOpenPicker={openPicker}
              onClosePicker={closePicker}
            />
          </>
        )}

        {view === 'edit' && isEmpty && (
          <EmptyState scopeLabel={scopeLabel}
                      onApplyPreset={applyPreset}
                      onAddBlank={addBinding} />
        )}

        {view === 'reference' && (
          <ReferenceView allBindings={bindings}
                         currentSiteId={scope === 'global' ? SERVICES[0].id : scope}
                         onPickSite={() => {}} />
        )}
      </div>

      {/* Modal pickers */}
      {picker && t.pickerVariant === 'modal' && editingId && (
        <ActionPickerModal
          scope={scope}
          onClose={closePicker}
          onPick={(a) => {
            const b = currentBindings.find((x) => x.id === editingId);
            const defaults = {};
            a.opts.forEach((o) => { defaults[o.key] = o.default; });
            updateBinding({ ...b, action: a.id, opts: defaults });
            closePicker();
          }} />
      )}
      {picker && t.pickerVariant === 'palette' && editingId && (
        <ActionPickerPalette
          scope={scope}
          onClose={closePicker}
          onPick={(a) => {
            const b = currentBindings.find((x) => x.id === editingId);
            const defaults = {};
            a.opts.forEach((o) => { defaults[o.key] = o.default; });
            updateBinding({ ...b, action: a.id, opts: defaults });
            closePicker();
          }} />
      )}

      {showSave && (
        <SaveDialog
          conflicts={conflictKeys}
          bindings={currentBindings}
          scopeLabel={scopeLabel}
          onCancel={() => setShowSave(false)}
          onSave={performSave} />
      )}
      {showImport && (
        <ImportDialog onClose={() => setShowImport(false)}
                      onApply={() => { setShowImport(false); setSavedToast(true);
                                       setTimeout(() => setSavedToast(false), 1600); }} />
      )}
      {showExport && (
        <ExportDialog onClose={() => setShowExport(false)} />
      )}

      {savedToast && (
        <div style={{
          position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
          background: 'var(--accent)', color: 'var(--accent-fg)',
          padding: '8px 14px', borderRadius: 999, fontSize: 12,
          display: 'flex', alignItems: 'center', gap: 8,
          boxShadow: '0 8px 24px rgba(20,18,15,.25)', zIndex: 200,
        }}>
          <Icon name="check" size={12} /> 保存しました
        </div>
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label="アクションピッカー">
          <TweakRadio label="形態" value={t.pickerVariant}
                      options={[
                        { value: 'inline', label: 'インライン' },
                        { value: 'modal', label: 'モーダル' },
                        { value: 'palette', label: '⌘K' },
                      ]}
                      onChange={(v) => setTweak('pickerVariant', v)} />
        </TweakSection>
        <TweakSection label="サイドバー">
          <TweakRadio label="Site 表示"
                      value={t.showSiteCatalog}
                      options={[
                        { value: 'configured-only', label: '設定済みのみ' },
                        { value: 'all', label: '全サイト' },
                      ]}
                      onChange={(v) => setTweak('showSiteCatalog', v)} />
        </TweakSection>
        <TweakSection label="アクセント">
          <TweakColor label="Accent" value={t.accent}
                      options={['neutral', 'indigo', 'green']}
                      onChange={(v) => setTweak('accent', v)} />
        </TweakSection>
        <TweakSection label="表示密度">
          <TweakRadio label="Density" value={t.density}
                      options={[
                        { value: 'compact', label: 'コンパクト' },
                        { value: 'comfortable', label: '標準' },
                      ]}
                      onChange={(v) => setTweak('density', v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );

  function hasUnsavedChanges() { return true; /* always show as enabled in mock */ }
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
