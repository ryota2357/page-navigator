// page-navigator — keyboard visualization for the per-site Reference view.

const { useMemo: __kbM } = React;

// Build a map of single-key triggers → binding (taking the first match for that key).
// Site-scope bindings shadow Global ones for the same key.
function buildKeyMap(globalBindings, siteBindings) {
  const m = {}; // key char (lowercased) → { binding, fromSite }
  globalBindings.forEach((b) => {
    b.triggers.forEach((t) => {
      if (t.length !== 1) return;
      const k = t[0].toLowerCase();
      if (!m[k]) m[k] = { binding: b, fromSite: false };
    });
  });
  siteBindings.forEach((b) => {
    b.triggers.forEach((t) => {
      if (t.length !== 1) return;
      const k = t[0].toLowerCase();
      m[k] = { binding: b, fromSite: true };
    });
  });
  return m;
}

function Keyboard({ layout, keyMap }) {
  return (
    <div className="kb">
      {layout.map((row, ri) => (
        <div key={ri} className="kb-row">
          {row.map((key, ki) => {
            const ch = key.c;
            const lc = ch.toLowerCase();
            const hit = keyMap[lc];
            const action = hit ? ACTIONS.find((a) => a.id === hit.binding.action) : null;
            const cls = ['kb-key',
                         key.w ? key.w : '',
                         hit ? 'bound' : '',
                         hit?.fromSite ? 'site' : ''
                        ].filter(Boolean).join(' ');
            return (
              <div key={ki} className={cls} title={action?.name || ''}>
                <span className="kc">{ch}</span>
                <span className="ka">{action ? action.name.replace(/^[a-z]+/, (m) => m) : ''}</span>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// Cheat-sheet list grouped by category. Includes both global + site bindings,
// with a "source" tag showing whether the row comes from Global or the site.
function CheatList({ globalBindings, siteBindings, siteName, query }) {
  const rows = __kbM(() => {
    const arr = [];
    siteBindings.forEach((b) => arr.push({ b, src: 'site' }));
    globalBindings.forEach((b) => {
      // Skip global rows whose first trigger key is shadowed by a site-binding.
      const shadowed = siteBindings.some((sb) =>
        sb.triggers.some((t) => b.triggers.some((g) => serializeTrigger(t) === serializeTrigger(g))));
      if (!shadowed) arr.push({ b, src: 'global' });
    });
    return arr;
  }, [globalBindings, siteBindings]);

  const filtered = __kbM(() => {
    if (!query) return rows;
    const q = query.toLowerCase();
    return rows.filter(({ b }) => {
      const a = ACTIONS.find((x) => x.id === b.action);
      const trig = b.triggers.map(serializeTrigger).join(' ').toLowerCase();
      return a?.name.toLowerCase().includes(q) ||
             a?.desc.toLowerCase().includes(q) ||
             trig.includes(q);
    });
  }, [rows, query]);

  const groups = {};
  filtered.forEach(({ b, src }) => {
    const a = ACTIONS.find((x) => x.id === b.action);
    if (!a) return;
    (groups[a.cat] ||= []).push({ b, src, a });
  });

  return (
    <div className="ref-rows">
      {CATEGORIES.map((cat) => {
        const items = groups[cat.id];
        if (!items || items.length === 0) return null;
        return (
          <React.Fragment key={cat.id}>
            <div className="ref-cat-h">{cat.label}</div>
            {items.map(({ b, src, a }, i) => (
              <div className="ref-row" key={b.id + i}>
                <div className="keys">
                  {b.triggers.map((t, j) => (
                    <span className={'tkey' + (t.length > 1 ? ' compound' : '')} key={j}>
                      {t.map((k, ji) => (
                        <React.Fragment key={ji}>
                          {ji > 0 && <span className="tkey-plus">·</span>}
                          <span className="tkey-piece">{displayKey(k)}</span>
                        </React.Fragment>
                      ))}
                    </span>
                  ))}
                </div>
                <div>
                  <div className="nm">{a.name}</div>
                  <div className="ds">{a.desc}</div>
                </div>
                <div className="src" style={{ alignSelf: 'start' }}>
                  {src === 'site' ? siteName : 'Global'}
                </div>
              </div>
            ))}
          </React.Fragment>
        );
      })}
      {filtered.length === 0 && (
        <div className="muted" style={{ padding: 24, textAlign: 'center', fontSize: 12 }}>
          検索条件にマッチするバインディングがありません。
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Keyboard, CheatList, buildKeyMap });
