// page-navigator — sidebar (Global / Site Specific / System).

const { useState: __ssState } = React;

function Sidebar({ scope, setScope, view, setView,
                   bindingCounts, conflictCounts, configuredSites,
                   onAddSite, onShowImport, onShowExport, onShowReference }) {
  // Show services that have bindings + an Add menu for the rest.
  // Decision: hybrid — configured sites are shown by default; "Add site"
  // surfaces the catalog. (See design notes in app.jsx.)
  const allSites = SERVICES;
  const visible = allSites.filter((s) => configuredSites.has(s.id));
  const hidden  = allSites.filter((s) => !configuredSites.has(s.id));
  const [addOpen, setAddOpen] = __ssState(false);

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-mark">pn</div>
        <div className="brand-name">page-navigator</div>
        <span className="brand-state">on</span>
      </div>

      <div className="side-section">
        <div className="side-section-h"><span className="ttl">Scope</span></div>
        <div
          className={'side-item' + (scope === 'global' ? ' active' : '')}
          onClick={() => { setScope('global'); setView('edit'); }}
        >
          <span className="side-icon"><Icon name="globe" /></span>
          <span className="side-label">Global</span>
          {conflictCounts.global > 0 && (
            <span className="side-conflict" title={`${conflictCounts.global} conflicts`} />
          )}
          <span className="side-count">{bindingCounts.global || 0}</span>
        </div>
      </div>

      <div className="side-section">
        <div className="side-section-h">
          <span className="ttl">Site specific</span>
          <button className="side-add" title="Add site" onClick={() => setAddOpen((v) => !v)}>+</button>
        </div>
        {visible.length === 0 && !addOpen && (
          <button className="side-empty-cta" onClick={() => setAddOpen(true)}>
            <Icon name="plus" size={12} /> Add a site to override Global
          </button>
        )}
        {visible.map((s) => (
          <div key={s.id}
               className={'side-item' + (scope === s.id ? ' active' : '')}
               onClick={() => { setScope(s.id); setView('edit'); }}>
            <SiteFav service={s} />
            <span className="side-label">{s.name}</span>
            {conflictCounts[s.id] > 0 && (
              <span className="side-conflict" title={`${conflictCounts[s.id]} conflicts`} />
            )}
            <span className="side-count">{bindingCounts[s.id] || 0}</span>
          </div>
        ))}
        {addOpen && (
          <div style={{ padding: '6px 8px 4px' }}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', textTransform: 'uppercase',
                          letterSpacing: '.1em', padding: '4px 2px 6px' }}>
              Available sites
            </div>
            {hidden.length === 0 ? (
              <div className="muted" style={{ fontSize: 11.5, padding: '4px 2px' }}>
                All supported sites are already configured.
              </div>
            ) : hidden.map((s) => (
              <div key={s.id} className="side-item"
                   onClick={() => { onAddSite(s.id); setAddOpen(false); }}>
                <SiteFav service={s} />
                <span className="side-label">{s.name}</span>
                <span className="side-count">add</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="side-spacer" />

      <div className="side-system">
        <div className="side-section-h" style={{ paddingTop: 0 }}>
          <span className="ttl">System</span>
        </div>
        <div className="side-item"
             onClick={onShowReference}>
          <span className="side-icon"><Icon name="book" /></span>
          <span className="side-label">Reference</span>
        </div>
        <div className="side-item" onClick={onShowImport}>
          <span className="side-icon"><Icon name="import" /></span>
          <span className="side-label">Import…</span>
        </div>
        <div className="side-item" onClick={onShowExport}>
          <span className="side-icon"><Icon name="export" /></span>
          <span className="side-label">Export…</span>
        </div>
        <div className="side-item">
          <span className="side-icon"><Icon name="gear" /></span>
          <span className="side-label">Preferences</span>
        </div>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
