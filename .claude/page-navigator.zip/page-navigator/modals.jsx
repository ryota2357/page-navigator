// page-navigator — modals: empty-state, presets, import, save-confirm, reference.

const { useState: __mS, useMemo: __mM } = React;

// ─── Empty state with preset cards ──────────────────────────────────────
function EmptyState({ scopeLabel, onApplyPreset, onAddBlank }) {
  return (
    <div className="empty">
      <h1 className="empty-h">{scopeLabel} のバインディングがありません</h1>
      <p className="empty-sub">
        プリセットを読み込んで素早く始めるか、空の状態から自分のキーマップを作ります。
        プリセットは適用後も自由に編集できます。
      </p>
      <div className="preset-grid">
        {PRESETS.map((p) => (
          <button key={p.id} className="preset-card" onClick={() => onApplyPreset(p)}>
            <div className="nm">
              <span className="code">{p.name}</span>
              <span className="badge global">{p.tag}</span>
            </div>
            <div className="ds">{p.desc}</div>
            <div className="keys">
              {p.keys.slice(0, 8).map((k, i) => <span key={i} className="kbd">{k}</span>)}
              {p.keys.length > 8 && <span className="muted code" style={{ fontSize: 11 }}>+{p.keys.length - 8}</span>}
            </div>
            <div className="ft">
              <span>{p.bindingCount} bindings</span>
              <span className="ld">適用 <Icon name="enter" size={11} /></span>
            </div>
          </button>
        ))}
      </div>

      <div className="empty-or">— OR —</div>

      <div className="empty-blank">
        <Icon name="plus" size={16} />
        <div>
          <b>空の状態から作る</b>
          <span>1 つずつバインディングを追加します</span>
        </div>
        <button className="tbtn" onClick={onAddBlank}>新規追加</button>
      </div>
    </div>
  );
}

// ─── Save confirmation w/ conflict list ─────────────────────────────────
function SaveDialog({ conflicts, bindings, scopeLabel, onCancel, onSave }) {
  // Group bindings by their conflicting trigger
  const groupedByKey = __mM(() => {
    const m = {};
    [...conflicts].forEach((k) => { m[k] = []; });
    bindings.forEach((b) => {
      b.triggers.forEach((t) => {
        const k = serializeTrigger(t);
        if (m[k]) m[k].push(b);
      });
    });
    return m;
  }, [conflicts, bindings]);

  return (
    <div className="modal-scrim" onClick={onCancel}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          <div>
            <div className="ttl">変更を保存しますか?</div>
            <div className="sub">{scopeLabel} のバインディングを書き出します</div>
          </div>
          <button className="modal-x" onClick={onCancel}>×</button>
        </div>
        <div className="modal-body">
          {conflicts.size === 0 ? (
            <div className="alert subtle">
              <Icon name="check" size={14} />
              <div>
                <b>競合なし</b>
                すべてのトリガーがユニークです。そのまま保存します。
              </div>
            </div>
          ) : (
            <>
              <div className="alert danger">
                <Icon name="warn" size={14} />
                <div>
                  <b>{conflicts.size} 件のキー競合があります</b>
                  以下のキーは複数のバインディングに割り当てられているため、
                  実行時にいずれも発火しません。
                </div>
              </div>
              <div className="dialog-conflict-list">
                {[...conflicts].map((k) => {
                  const seq = k.split(' ');
                  return (
                    <div className="row" key={k}>
                      <div className="key">
                        <span className="tkey conflict">
                          {seq.map((kk, j) => (
                            <React.Fragment key={j}>
                              {j > 0 && <span className="tkey-plus">·</span>}
                              <span className="tkey-piece">{displayKey(kk)}</span>
                            </React.Fragment>
                          ))}
                        </span>
                      </div>
                      <div className="actions">
                        {groupedByKey[k].map((b) => {
                          const a = ACTIONS.find((x) => x.id === b.action);
                          return (
                            <span key={b.id} className="code">
                              <span>{a?.name || '—'}</span>
                              {a?.opts.length > 0 && (
                                <span style={{ color: 'var(--text-3)' }}>
                                  {' ('}{Object.entries(b.opts).map(([k,v]) => `${k}: ${v}`).join(', ')}{')'}
                                </span>
                              )}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="muted" style={{ fontSize: 11.5, marginTop: 12 }}>
                どれを残すかは戻って手動で修正してください。「このまま保存」を選んだ場合、
                競合中のキーは押しても何も起きません。
              </p>
            </>
          )}
        </div>
        <div className="modal-foot">
          <button className="tbtn ghost" onClick={onCancel}>戻る</button>
          {conflicts.size > 0 ? (
            <button className="tbtn danger" onClick={onSave}>このまま保存</button>
          ) : (
            <button className="tbtn primary" onClick={onSave}>保存</button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Import dialog ──────────────────────────────────────────────────────
const FAKE_IMPORT_SCOPES = [
  { id: 'global', name: 'Global', count: 32, kind: 'global' },
  { id: 'google', name: 'Google', count: 9, kind: 'site' },
  { id: 'github', name: 'GitHub', count: 14, kind: 'site' },
  { id: 'reddit', name: 'Reddit', count: 6, kind: 'site' },
];

function ImportDialog({ onClose, onApply }) {
  const [picks, setPicks] = __mS(() => {
    const o = {};
    FAKE_IMPORT_SCOPES.forEach((s) => o[s.id] = { include: true, mode: 'replace' });
    return o;
  });
  const togInc = (id) => setPicks((p) => ({ ...p, [id]: { ...p[id], include: !p[id].include } }));
  const setMode = (id, mode) => setPicks((p) => ({ ...p, [id]: { ...p[id], mode } }));
  const includedCount = Object.values(picks).filter((p) => p.include).length;

  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal lg" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          <div>
            <div className="ttl">設定をインポート</div>
            <div className="sub">JSON ファイルから読み込むスコープを選択します</div>
          </div>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="dropzone">
            <Icon name="import" size={18} />
            <div className="pf">
              <b>page-navigator-config.json</b>
              <span className="meta">4.2 KB · 4 scope · 61 bindings</span>
            </div>
            <button className="tbtn ghost">別のファイル</button>
          </div>

          <div style={{ marginTop: 18 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 6 }}>
              <div style={{ fontSize: 11, color: 'var(--text-3)', letterSpacing: '.1em',
                            textTransform: 'uppercase', fontWeight: 600 }}>
                Scopes in file
              </div>
              <div className="muted" style={{ fontSize: 11.5 }}>
                {includedCount} / {FAKE_IMPORT_SCOPES.length} 選択中
              </div>
            </div>
            {FAKE_IMPORT_SCOPES.map((s) => {
              const p = picks[s.id];
              const svc = s.kind === 'site' ? SERVICES.find((x) => x.id === s.id) : null;
              return (
                <div className="import-scope-row" key={s.id}>
                  <div className="checkbox" data-on={String(p.include)}
                       onClick={() => togInc(s.id)} role="checkbox" />
                  <div className="nm">
                    {svc ? <SiteFav service={svc} size={18} /> : <Icon name="globe" />}
                    <span>{s.name}</span>
                  </div>
                  <div className="cnt">{s.count} bindings</div>
                  <div className="seg" style={{ opacity: p.include ? 1 : 0.4, pointerEvents: p.include ? 'auto' : 'none' }}>
                    <button data-on={String(p.mode === 'merge')}
                            onClick={() => setMode(s.id, 'merge')}>追加 (merge)</button>
                    <button data-on={String(p.mode === 'replace')}
                            onClick={() => setMode(s.id, 'replace')}>上書き (replace)</button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="note" style={{ marginTop: 14 }}>
            <b style={{ color: 'var(--text-1)', fontWeight: 500 }}>追加 (merge):</b>{' '}
            既存のバインディングは残し、新しいものだけ追加します。
            同じトリガーがあれば競合扱いになります。
            <br />
            <b style={{ color: 'var(--text-1)', fontWeight: 500 }}>上書き (replace):</b>{' '}
            このスコープの既存バインディングを削除してから読み込みます。
          </div>
        </div>
        <div className="modal-foot">
          <button className="tbtn ghost" onClick={onClose}>キャンセル</button>
          <button className="tbtn primary" onClick={onApply} disabled={includedCount === 0}>
            適用 ({includedCount})
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Reference view (cheat sheet) ───────────────────────────────────────
function ReferenceView({ allBindings, currentSiteId, onPickSite, onBack }) {
  const [layout, setLayout] = __mS('qwerty');
  const [siteId, setSiteId] = __mS(currentSiteId || 'none');
  const [query, setQuery] = __mS('');
  const isNone = siteId === 'none';
  const site = isNone ? null : SERVICES.find((s) => s.id === siteId);
  const keyMap = __mM(() => buildKeyMap(allBindings.global || [], isNone ? [] : (allBindings[siteId] || [])),
                      [allBindings, siteId, isNone]);

  return (
    <div className="ref-wrap">
      <div className="list-toolbar" style={{ paddingLeft: 0, paddingRight: 0 }}>
        {onBack && (
          <button className="tbtn ghost" onClick={onBack}>
            <Icon name="arrow-left" size={12} /> 編集に戻る
          </button>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="muted" style={{ fontSize: 12 }}>Site:</span>
          <select className="opt-select" value={siteId} onChange={(e) => setSiteId(e.target.value)}
                  style={{ width: 'auto', height: 30, fontSize: 12.5,
                           paddingLeft: 10, paddingRight: 28, fontFamily: 'inherit' }}>
            <option value="none">サイト固有なし (Global のみ)</option>
            {SERVICES.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div className="search-input" style={{ flex: 1, maxWidth: 360 }}>
          <Icon name="search" size={14} />
          <input placeholder="このサイトのキーマップを検索…"
                 value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <button className="tbtn ghost" title="Print this cheat sheet">
          <Icon name="export" size={13} /> Print
        </button>
      </div>

      <div className="kb-wrap">
        <div className="kb-head">
          <span>
            {isNone ? (
              <>
                <b style={{ color: 'var(--text-1)' }}>サイト固有設定なし</b> —{' '}
                Global のバインディングだけが有効です
              </>
            ) : (
              <>
                <b style={{ color: 'var(--text-1)' }}>{site.name}</b> で発火するキー —{' '}
                <span style={{ color: 'var(--site-tag)' }}>{site.name} 固有</span>{' '}
                は Global を上書きします
              </>
            )}
          </span>
          <div className="kb-layout-toggle">
            <button data-active={String(layout === 'qwerty')} onClick={() => setLayout('qwerty')}>QWERTY</button>
            <button data-active={String(layout === 'dvorak')} onClick={() => setLayout('dvorak')}>Dvorak</button>
          </div>
        </div>
        <Keyboard layout={KEYBOARD_LAYOUTS[layout]} keyMap={keyMap} />
        <div style={{ display: 'flex', gap: 16, fontSize: 11, color: 'var(--text-3)',
                      paddingTop: 6 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span className="kb-key bound" style={{ minWidth: 14, height: 14, padding: 0 }} />
            Global
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span className="kb-key bound site" style={{ minWidth: 14, height: 14, padding: 0 }} />
            {isNone ? 'サイト固有' : `${site.name} 固有`}
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span className="kb-key" style={{ minWidth: 14, height: 14, padding: 0 }} />
            未割り当て
          </span>
          <span style={{ marginLeft: 'auto' }}>
            複数キー (例: <span className="kbd">g</span> <span className="kbd">g</span>)
            は下のリストにのみ表示
          </span>
        </div>
      </div>

      <div className="ref-list">
        <CheatList globalBindings={allBindings.global || []}
                   siteBindings={isNone ? [] : (allBindings[siteId] || [])}
                   siteName={isNone ? '—' : site.name}
                   query={query} />
      </div>
    </div>
  );
}

// ─── Export dialog (simple) ─────────────────────────────────────────────
function ExportDialog({ onClose }) {
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          <div>
            <div className="ttl">設定をエクスポート</div>
            <div className="sub">現在の全スコープを 1 つの JSON ファイルに書き出します</div>
          </div>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div className="dropzone" style={{ borderStyle: 'solid', background: 'var(--surface)' }}>
            <Icon name="export" size={18} />
            <div className="pf">
              <b>page-navigator-config.json</b>
              <span className="meta">4 scope · 47 bindings · 約 4 KB</span>
            </div>
          </div>
          <div className="note" style={{ marginTop: 14 }}>
            読み込み側でスコープごとの取捨選択ができるため、
            ここでは個別の選択 UI は省いています。
          </div>
        </div>
        <div className="modal-foot">
          <button className="tbtn ghost" onClick={onClose}>キャンセル</button>
          <button className="tbtn primary"><Icon name="export" size={12} /> ダウンロード</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EmptyState, SaveDialog, ImportDialog, ExportDialog, ReferenceView,
                        TriggerCaptureModal, AddSiteModal });

// ─── Trigger capture modal ──────────────────────────────────────────────
// Opens when the user clicks "+ add key" on a binding row in edit mode.
// Records keys (single key, modifier+key, or vim-style multi-step sequence).
// Closes only via UI buttons — so Enter / Esc themselves are bindable.
function TriggerCaptureModal({ scope, existingTriggers, onClose, onCommit }) {
  // `seq` = array of tokens captured so far (e.g. ['g', 'g'] or ['<C-x>', 'k'])
  const [seq, setSeq] = __mS([]);
  const [activeMods, setActiveMods] = __mS({ C: false, S: false, A: false, M: false });
  const [pressedToken, setPressedToken] = __mS(null); // last completed key — flashes briefly

  React.useEffect(() => {
    const update = (e) => setActiveMods({
      C: e.ctrlKey, S: e.shiftKey, A: e.altKey, M: e.metaKey,
    });
    const onDown = (e) => {
      // Don't let any in-page handler swallow these — including app's global ESC.
      e.preventDefault();
      e.stopPropagation();
      update(e);
      const tok = keyEventToToken(e);
      if (!tok) return; // pure modifier press
      setSeq((s) => [...s, tok]);
      setPressedToken(tok);
      // brief visual feedback
      window.setTimeout(() => setPressedToken((cur) => cur === tok ? null : cur), 280);
    };
    const onUp = (e) => update(e);
    window.addEventListener('keydown', onDown, true);
    window.addEventListener('keyup',   onUp,   true);
    return () => {
      window.removeEventListener('keydown', onDown, true);
      window.removeEventListener('keyup',   onUp,   true);
    };
  }, []);

  const popLast = () => setSeq((s) => s.slice(0, -1));
  const clear   = () => setSeq([]);

  // Friendly preview of the canonical trigger string for the docs / config file
  const preview = seq.length === 0
    ? '(まだ何も入力されていません)'
    : seq.map(displayKey).join(' ');

  return (
    <div className="modal-scrim capture-scrim" onClick={onClose}>
      <div className="modal capture-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h capture-h">
          <div className="capture-h-row">
            <span className="capture-dot" />
            <div>
              <div className="ttl">トリガー入力中…</div>
              <div className="sub">
                <Icon name="keyboard" size={11} /> キーを押すとシーケンスに追加されます。
              </div>
            </div>
          </div>
        </div>

        <div className="modal-body capture-body">
          {/* Live captured sequence */}
          <div className="capture-stage">
            {seq.length === 0 ? (
              <div className="capture-empty">
                <span className="capture-empty-icon"><Icon name="record" size={20} /></span>
                <div>
                  <b>キーを押してください</b>
                  <span className="muted">
                    例: <span className="kbd code">j</span> ・
                    <span className="kbd code">{'<C-a>'}</span> ・
                    <span className="kbd code">g</span><span className="kbd code">g</span> (連続入力で複合トリガー)
                  </span>
                </div>
              </div>
            ) : (
              <div className="capture-seq">
                {seq.map((tok, i) => (
                  <span key={i}
                        className={'tkey capture-tok' + (pressedToken === tok && i === seq.length - 1 ? ' flash' : '')}>
                    <span className="tkey-piece">{displayKey(tok)}</span>
                  </span>
                ))}
                <span className="capture-cursor" aria-hidden />
              </div>
            )}
          </div>

          {/* Live modifier indicator */}
          <div className="capture-mods">
            <span className="muted" style={{ fontSize: 11 }}>修飾キー</span>
            <span className={'mod-chip' + (activeMods.C ? ' on' : '')}>Ctrl</span>
            <span className={'mod-chip' + (activeMods.S ? ' on' : '')}>Shift</span>
            <span className={'mod-chip' + (activeMods.A ? ' on' : '')}>Alt</span>
            <span className={'mod-chip' + (activeMods.M ? ' on' : '')}>⌘ / Meta</span>
            <span style={{ marginLeft: 'auto', fontSize: 11 }} className="muted">
              {seq.length} key{seq.length === 1 ? '' : 's'} captured
            </span>
          </div>

          {/* Canonical preview (what gets stored) removed per user request */}


        </div>

        <div className="modal-foot">
          <button className="tbtn ghost" onClick={popLast} disabled={seq.length === 0}
                  title="最後の 1 キーを削除">
            <Icon name="arrow-left" size={12} /> 1 つ戻す
          </button>
          <button className="tbtn ghost" onClick={clear} disabled={seq.length === 0}>
            クリア
          </button>
          <span style={{ flex: 1 }} />
          <button className="tbtn ghost" onClick={onClose}>キャンセル</button>
          <button className="tbtn primary"
                  onClick={() => onCommit(seq)}
                  disabled={seq.length === 0}>
            <Icon name="check" size={12} /> このキーで確定
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Add site modal ─────────────────────────────────────────────────────
function AddSiteModal({ existingIds, onClose, onPick }) {
  const [q, setQ] = __mS('');
  const ids = new Set(existingIds);
  const available = SERVICES.filter((s) => !ids.has(s.id));
  const filtered = available.filter((s) => {
    if (!q) return true;
    const qq = q.toLowerCase();
    return s.name.toLowerCase().includes(qq) || s.domain.toLowerCase().includes(qq);
  });

  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          <div>
            <div className="ttl">サイトを追加</div>
            <div className="sub">サイト固有のバインディングを編集できるようにします</div>
          </div>
          <button className="modal-x" onClick={onClose}>×</button>
        </div>
        <div className="picker-search" style={{ borderBottom: '1px solid var(--border)' }}>
          <Icon name="search" size={14} />
          <input autoFocus value={q}
                 onChange={(e) => setQ(e.target.value)}
                 placeholder="サイト名やドメインで絞り込み…" />
        </div>
        <div className="modal-body" style={{ padding: 6 }}>
          {filtered.length === 0 ? (
            <div className="muted" style={{ padding: 24, textAlign: 'center', fontSize: 12 }}>
              {available.length === 0
                ? 'すべての対応サイトが既に追加されています。'
                : '一致するサイトはありません。'}
            </div>
          ) : (
            <div className="add-site-list">
              {filtered.map((s) => (
                <button key={s.id} className="add-site-row" onClick={() => onPick(s.id)}>
                  <SiteFav service={s} size={22} />
                  <span className="add-site-meta">
                    <span className="add-site-name">{s.name}</span>
                    <span className="add-site-domain code">{s.domain}</span>
                  </span>
                  <span className="add-site-add">
                    <Icon name="plus" size={12} /> 追加
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="modal-foot">
          <button className="tbtn ghost" onClick={onClose}>閉じる</button>
        </div>
      </div>
    </div>
  );
}
