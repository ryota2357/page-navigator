// page-navigator — root app component.
// Composes sidebar + main view (bindings list / reference) + modals + tweaks.
//
// Major redesign decisions:
//   - Sidebar is a flat list (Global + configured sites). No SCOPE / Site Specific
//     section headers — they added structure without information. Sites are
//     drag-reorderable; "+ Add site…" opens a modal.
//   - Header (sticky toolbar w/ crumb + "Reference" button) is gone — the
//     sidebar already tells you which scope you're viewing, and Reference is
//     a sidebar item.
//   - Trigger capture is a modal — supports modifier keys (vim notation
//     <C-a>) and multi-step sequences. Enter / Esc are bindable because the
//     modal closes only via UI buttons.
//   - Bindings list row has a drag handle on the right for reorder. Delete
//     moved into editing mode only.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

const SCOPE_LABELS = {
  global: 'Global',
};
SERVICES.forEach((s) => { SCOPE_LABELS[s.id] = s.name; });

function App() {
  // ─── State ───
  const [scope, setScope] = useState('global');
  const [view, setView] = useState('edit');
  const [bindings, setBindings] = useState(initialBindings);
  // Site order — initialized to sites that already have bindings, in SERVICES order.
  const [siteOrder, setSiteOrder] = useState(() =>
    SERVICES.filter((s) => (initialBindings[s.id] || []).length > 0).map((s) => s.id)
  );
  const [editingId, setEditingId] = useState(null);
  const [picker, setPicker] = useState(null);
  const [captureFor, setCaptureFor] = useState(null);   // bindingId or '__new__'
  const [showAddSite, setShowAddSite] = useState(false);
  const [showSave, setShowSave] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [query, setQuery] = useState('');
  const [savedToast, setSavedToast] = useState(false);

  // Preferences (global app settings, separate from per-scope bindings).
  const [prefs, setPrefs] = useState({
    sequenceTimeout: 850,
    disabledPages: [
      'mail.google.com/*',
      'docs.google.com/*',
    ],
  });

  const currentBindings = bindings[scope] || [];
  const conflictKeys = useMemo(() => findConflicts(currentBindings), [currentBindings]);

  const bindingCounts = useMemo(() => {
    const o = { global: bindings.global?.length || 0 };
    SERVICES.forEach((s) => o[s.id] = bindings[s.id]?.length || 0);
    return o;
  }, [bindings]);

  const conflictCounts = useMemo(() => {
    const o = { global: findConflicts(bindings.global || []).size };
    SERVICES.forEach((s) => o[s.id] = findConflicts(bindings[s.id] || []).size);
    return o;
  }, [bindings]);

  // ─── Bindings mutations ───
  const updateBinding = (b) => setBindings((all) => ({
    ...all,
    [scope]: (all[scope] || []).map((x) => x.id === b.id ? b : x),
  }));
  const deleteBinding = (id) => {
    setBindings((all) => ({
      ...all,
      [scope]: (all[scope] || []).filter((x) => x.id !== id),
    }));
    if (editingId === id) setEditingId(null);
  };
  const addBinding = () => {
    const id = 'b' + Math.random().toString(36).slice(2, 8);
    const newB = { id, triggers: [], action: '', opts: {} };
    setBindings((all) => ({ ...all, [scope]: [...(all[scope] || []), newB] }));
    setEditingId(id);
    // Scroll to & focus the newly added row after it lands in the DOM.
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const el = document.querySelector(`[data-binding-id="${id}"]`);
        if (el) {
          el.scrollIntoView({ block: 'center', behavior: 'smooth' });
          el.classList.add('just-added');
          setTimeout(() => el.classList.remove('just-added'), 1200);
        }
      });
    });
  };
  const reorderBindings = (idsInOrder) => {
    setBindings((all) => {
      const byId = new Map((all[scope] || []).map((b) => [b.id, b]));
      return { ...all, [scope]: idsInOrder.map((id) => byId.get(id)).filter(Boolean) };
    });
  };

  const startEdit = (id) => setEditingId(id);
  const commitEdit = () => { setEditingId(null); setPicker(null); };
  const cancelEdit = () => { setEditingId(null); setPicker(null); };

  // ─── Trigger capture ───
  const startCapture = (bindingId) => setCaptureFor(bindingId);
  const commitCapture = (seq) => {
    if (!captureFor || seq.length === 0) { setCaptureFor(null); return; }
    setBindings((all) => ({
      ...all,
      [scope]: (all[scope] || []).map((b) =>
        b.id === captureFor ? { ...b, triggers: [...b.triggers, seq] } : b),
    }));
    setCaptureFor(null);
  };

  // ─── Sites ───
  const addSite = (id) => {
    setBindings((all) => ({ ...all, [id]: all[id] || [] }));
    setSiteOrder((order) => order.includes(id) ? order : [...order, id]);
    setScope(id); setView('edit');
    setShowAddSite(false);
  };
  const reorderSites = (next) => setSiteOrder(next);

  // ─── Picker ───
  const openPicker = (bindingId, ref) => {
    setPicker({ bindingId });
  };
  const closePicker = () => setPicker(null);

  const applyPreset = (preset) => {
    const synth = preset.id === 'vim-like' ? initialBindings.global.slice(0, preset.bindingCount)
                  : preset.id === 'arrows' ? [
                      { id: 'p1', triggers: [['Down']], action: 'scrollDown', opts: { amount: 100 } },
                      { id: 'p2', triggers: [['Up']],   action: 'scrollUp',   opts: { amount: 100 } },
                      { id: 'p3', triggers: [['Left']], action: 'goBack',    opts: {} },
                      { id: 'p4', triggers: [['Right']],action: 'goForward', opts: {} },
                      { id: 'p5', triggers: [['Escape']], action: 'blurFocus', opts: {} },
                      { id: 'p6', triggers: [[' ']], action: 'scrollPageDown', opts: { overlap: 40 } },
                    ]
                  : initialBindings.global.slice(0, preset.bindingCount);
    setBindings((all) => ({ ...all, [scope]: synth }));
  };

  const performSave = () => {
    setShowSave(false);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 1600);
  };

  // ESC closes editing / picker / dialogs (but NOT when capturing — Esc is bindable).
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      if (captureFor) return;
      if (picker) { setPicker(null); return; }
      if (showAddSite) { setShowAddSite(false); return; }
      if (showSave) { setShowSave(false); return; }
      if (showImport) { setShowImport(false); return; }
      if (showExport) { setShowExport(false); return; }
      if (editingId) { setEditingId(null); return; }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [editingId, picker, captureFor, showAddSite, showSave, showImport, showExport]);

  const scopeLabel = SCOPE_LABELS[scope];
  const scopeService = SERVICES.find((s) => s.id === scope);
  const isEmpty = currentBindings.length === 0;

  return (
    <div className="app" data-screen-label={
      view === 'reference' ? 'Reference' :
      view === 'preferences' ? 'Preferences' :
      `${scopeLabel} bindings`
    }>
      <Sidebar
        scope={scope} setScope={setScope}
        view={view} setView={setView}
        bindingCounts={bindingCounts}
        conflictCounts={conflictCounts}
        siteOrder={siteOrder}
        onReorderSites={reorderSites}
        onShowAddSite={() => setShowAddSite(true)}
        onShowImport={() => setShowImport(true)}
        onShowExport={() => setShowExport(true)}
        onShowReference={() => setView('reference')}
        onShowPreferences={() => setView('preferences')}
      />

      <div className="main">
        {view === 'edit' && !isEmpty && (
          <>
            <div className="scope-head">
              <div className="scope-head-icon">
                {scopeService ? <SiteFav service={scopeService} size={24} />
                              : <div className="scope-globe"><Icon name="globe" size={14} /></div>}
              </div>
              <div className="scope-head-text">
                <div className="scope-head-name">
                  {scope === 'global' ? 'Global' : scopeService.name}
                </div>
                <div className="scope-head-sub">
                  {scope === 'global'
                    ? 'すべてのページで有効。サイト固有の設定があれば、そちらが優先されます。'
                    : `${scopeService.domain} でのみ有効 — Global を上書きします`}
                </div>
              </div>
              <div className="scope-head-meta">
                <span className="muted" style={{ fontSize: 11.5 }}>
                  {currentBindings.length} bindings
                  {conflictKeys.size > 0 && (
                    <> · <span style={{ color: 'var(--danger)' }}>{conflictKeys.size} 競合</span></>
                  )}
                </span>
              </div>
            </div>

            {conflictKeys.size > 0 && (
              <ConflictBanner count={conflictKeys.size} onJump={() => {
                const first = currentBindings.find((b) =>
                  b.triggers.some((t) => conflictKeys.has(serializeTrigger(t))));
                if (first) {
                  setEditingId(first.id);
                  const el = document.querySelector(`[data-binding-id="${first.id}"]`);
                  el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
                }
              }} />
            )}
            <div className="list-toolbar">
              <div className="search-input">
                <Icon name="search" size={14} />
                <input value={query} onChange={(e) => setQuery(e.target.value)}
                       placeholder="トリガーやアクション名で絞り込み…" />
                <Kbd>/</Kbd>
              </div>
              <button className="tbtn" onClick={addBinding}>
                <Icon name="plus" size={13} /> 新規追加
              </button>
            </div>
            <BindingsList
              bindings={currentBindings}
              scope={scope}
              editingId={editingId}
              picker={picker}
              pickerVariant={'modal'}
              query={query}
              onStartEdit={startEdit}
              onCommitEdit={commitEdit}
              onCancelEdit={cancelEdit}
              onDelete={deleteBinding}
              onChange={updateBinding}
              onAdd={addBinding}
              onReorder={reorderBindings}
              onStartCapture={startCapture}
              onOpenPicker={openPicker}
              onClosePicker={closePicker}
            />
          </>
        )}

        {view === 'edit' && isEmpty && (
          <EmptyState scopeLabel={scopeLabel}
                      onApplyPreset={applyPreset}
                      onAddBlank={addBinding} />
        )}

        {view === 'reference' && (
          <ReferenceView allBindings={bindings}
                         currentSiteId={scope === 'global' ? (siteOrder[0] || SERVICES[0].id) : scope}
                         onBack={() => setView('edit')}
                         onPickSite={() => {}} />
        )}

        {view === 'preferences' && (
          <Preferences value={prefs} onChange={setPrefs}
                       onBack={() => setView('edit')} />
        )}
      </div>

      {/* Capture modal */}
      {captureFor && (
        <TriggerCaptureModal
          scope={scope}
          existingTriggers={(currentBindings.find((b) => b.id === captureFor) || {}).triggers || []}
          onClose={() => setCaptureFor(null)}
          onCommit={commitCapture} />
      )}

      {/* Add-site modal */}
      {showAddSite && (
        <AddSiteModal
          existingIds={siteOrder}
          onClose={() => setShowAddSite(false)}
          onPick={addSite} />
      )}

      {/* Action picker (always modal) */}
      {picker && editingId && (
        <ActionPickerModal
          scope={scope}
          onClose={closePicker}
          onPick={(a) => {
            const b = currentBindings.find((x) => x.id === editingId);
            const defaults = {};
            a.opts.forEach((o) => { defaults[o.key] = o.default; });
            updateBinding({ ...b, action: a.id, opts: defaults });
            closePicker();
          }} />
      )}

      {showSave && (
        <SaveDialog
          conflicts={conflictKeys}
          bindings={currentBindings}
          scopeLabel={scopeLabel}
          onCancel={() => setShowSave(false)}
          onSave={performSave} />
      )}
      {showImport && (
        <ImportDialog onClose={() => setShowImport(false)}
                      onApply={() => { setShowImport(false); setSavedToast(true);
                                       setTimeout(() => setSavedToast(false), 1600); }} />
      )}
      {showExport && (
        <ExportDialog onClose={() => setShowExport(false)} />
      )}

      {savedToast && (
        <div style={{
          position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
          background: 'var(--accent)', color: 'var(--accent-fg)',
          padding: '8px 14px', borderRadius: 999, fontSize: 12,
          display: 'flex', alignItems: 'center', gap: 8,
          boxShadow: '0 8px 24px rgba(20,18,15,.25)', zIndex: 200,
        }}>
          <Icon name="check" size={12} /> 保存しました
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
