// page-navigator — Preferences page (simplified).
// Two settings: sequence timeout (slider) and disabled pages (pattern list).

const { useState: __pS, useEffect: __pE, useRef: __pR } = React;

function Preferences({ value, onChange }) {
  const set = (k, v) => onChange({ ...value, [k]: v });
  return (
    <div className="prefs" data-screen-label="Preferences">
      <div className="prefs-head">
        <div className="prefs-head-name">Preferences</div>
      </div>

      <div className="prefs-sections">
        <SequenceTimeoutSection
          value={value.sequenceTimeout}
          onChange={(ms) => set('sequenceTimeout', ms)} />
        <DisabledPagesSection
          patterns={value.disabledPages}
          onChange={(list) => set('disabledPages', list)} />
      </div>
    </div>
  );
}

function SequenceTimeoutSection({ value, onChange }) {
  const min = 200, max = 2500;

  // Live tester — capture key presses; show a progress bar that depletes over
  // `value` ms. If next key arrives in time the sequence continues; otherwise
  // the box flashes "timeout" and resets.
  const [seq, setSeq] = __pS([]);
  const [armedAt, setArmedAt] = __pS(null);
  const [progress, setProgress] = __pS(0);
  const [expired, setExpired] = __pS(false);
  const [hasFocus, setHasFocus] = __pS(false);
  const rafRef = __pR(null);

  __pE(() => {
    if (armedAt == null) { setProgress(0); return; }
    let stop = false;
    const tick = () => {
      if (stop) return;
      const elapsed = performance.now() - armedAt;
      const p = Math.max(0, 1 - elapsed / value);
      setProgress(p);
      if (p <= 0) {
        setArmedAt(null);
        setExpired(true);
        setTimeout(() => setExpired(false), 1200);
        setTimeout(() => setSeq([]), 1400);
      } else {
        rafRef.current = requestAnimationFrame(tick);
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { stop = true; if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [armedAt, value]);

  const onKeyDown = (e) => {
    const tok = keyEventToToken(e);
    if (!tok) return;
    if (e.key === 'Tab' && !e.shiftKey) return;
    e.preventDefault();
    e.stopPropagation();
    setExpired(false);
    setSeq((s) => [...s, { tok, at: performance.now() }]);
    setArmedAt(performance.now());
  };

  return (
    <section className="pref-section">
      <div className="pref-row">
        <div className="pref-label">
          <div className="pref-title">Sequence timeout</div>
          <div className="pref-desc">
            連続キーの入力 (例: <Kbd>g</Kbd> <Kbd>g</Kbd>) で次のキーを待つ時間。
          </div>
        </div>
        <div className="pref-num-wrap">
          <input
            type="number"
            className="pref-num"
            min={min} max={max} step={10}
            value={value}
            onChange={(e) => {
              const n = Number(e.target.value);
              if (Number.isFinite(n)) onChange(Math.min(max, Math.max(min, n)));
            }} />
          <span className="pref-num-unit">ms</span>
        </div>
      </div>

      <div
        tabIndex={0}
        className={'pref-try-box'
          + (hasFocus ? ' focused' : '')
          + (expired ? ' expired' : '')}
        onFocus={() => setHasFocus(true)}
        onBlur={() => setHasFocus(false)}
        onKeyDown={onKeyDown}>
        {seq.length === 0 && !expired && (
          <div className="pref-try-placeholder">
            {hasFocus
              ? <><span className="pulse-dot" /> キーを押して試す…</>
              : <>クリックしてキーを押すと、連続入力として認識される様子を確認できます</>}
          </div>
        )}

        {expired && seq.length === 0 && (
          <div className="pref-try-expired">
            タイムアウト
          </div>
        )}

        {seq.length > 0 && (
          <div className="pref-try-timeline">
            {seq.map((k, i) => {
              const next = seq[i + 1];
              const gap = next ? Math.round(next.at - k.at) : null;
              return (
                <React.Fragment key={i}>
                  <span className="tkey capture-tok flash">
                    <span className="tkey-piece">{displayKey(k.tok)}</span>
                  </span>
                  {next && (
                    <span className="pref-try-gap" title={`${gap} ms`}>
                      <span className="pref-try-gap-line" />
                      <span className="pref-try-gap-num">{gap} ms</span>
                    </span>
                  )}
                </React.Fragment>
              );
            })}
            {armedAt != null && (
              <span className="pref-try-waiting">
                <span className="pref-try-bar">
                  <span className="pref-try-bar-fill"
                        style={{ transform: `scaleX(${progress})` }} />
                </span>
                <span className="pref-try-bar-num">
                  {Math.max(0, Math.round(value * progress))} ms
                </span>
              </span>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function DisabledPagesSection({ patterns, onChange }) {
  const [draft, setDraft] = __pS('');
  const trimmed = draft.trim();
  const isDup = trimmed && patterns.includes(trimmed);

  const add = () => {
    if (!trimmed || isDup) return;
    onChange([...patterns, trimmed]);
    setDraft('');
  };
  const remove = (p) => onChange(patterns.filter((x) => x !== p));

  return (
    <section className="pref-section">
      <div className="pref-row">
        <div className="pref-label">
          <div className="pref-title">Disabled pages</div>
          <div className="pref-desc">
            一致する URL ではキー入力を無視します。<code className="pref-code">*</code> でワイルドカード。
          </div>
        </div>
        <div className="pref-control">
          <div className="pref-pattern-input">
            <input
              type="text"
              spellCheck="false"
              value={draft}
              placeholder="例: mail.google.com/*"
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }} />
            <button
              className="tbtn pref-pattern-add"
              onClick={add}
              disabled={!trimmed || isDup}>
              追加
            </button>
          </div>

          {patterns.length > 0 && (
            <ul className="pref-pattern-rows">
              {patterns.map((p) => (
                <li key={p} className="pref-pattern-row">
                  <code className="pref-pattern-text">{p}</code>
                  <button className="pref-pattern-rm"
                          onClick={() => remove(p)}
                          aria-label={`${p} を削除`}>
                    <Icon name="trash" size={12} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}

window.Preferences = Preferences;
