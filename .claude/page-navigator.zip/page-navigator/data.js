// page-navigator — mock data for the design prototype.
// Globally exposed: ACTIONS, CATEGORIES, SERVICES, PRESETS,
// initialBindings, KEYBOARD_LAYOUTS.

const CATEGORIES = [
  { id: 'scroll',  label: 'Scrolling' },
  { id: 'nav',     label: 'Navigation' },
  { id: 'tab',     label: 'Tabs & Windows' },
  { id: 'focus',   label: 'Focus & Hints' },
  { id: 'find',    label: 'Find & Search' },
  { id: 'form',    label: 'Forms' },
  { id: 'site',    label: 'Site-specific' },
];

// A small but representative slice of the ~100+ actions. Each: id, name (technical),
// category, description, optional site, options schema.
const ACTIONS = [
  // Scrolling
  { id: 'scrollDown',     name: 'scrollDown',     cat: 'scroll',
    desc: '一定量だけ下へスクロール。amount は px 指定、inertia で慣性を有効化。',
    opts: [
      { key: 'amount',  type: 'number',  default: 100, unit: 'px' },
      { key: 'inertia', type: 'boolean', default: false },
    ] },
  { id: 'scrollUp',       name: 'scrollUp',       cat: 'scroll',
    desc: '一定量だけ上へスクロール。',
    opts: [
      { key: 'amount',  type: 'number',  default: 100, unit: 'px' },
      { key: 'inertia', type: 'boolean', default: false },
    ] },
  { id: 'scrollPageDown', name: 'scrollPageDown', cat: 'scroll',
    desc: '1 ビューポート分だけ下へスクロール。',
    opts: [
      { key: 'overlap', type: 'number',  default: 40, unit: 'px' },
    ] },
  { id: 'scrollPageUp',   name: 'scrollPageUp',   cat: 'scroll',
    desc: '1 ビューポート分だけ上へスクロール。',
    opts: [
      { key: 'overlap', type: 'number',  default: 40, unit: 'px' },
    ] },
  { id: 'scrollToTop',    name: 'scrollToTop',    cat: 'scroll',
    desc: 'ページ先頭へジャンプ。', opts: [] },
  { id: 'scrollToBottom', name: 'scrollToBottom', cat: 'scroll',
    desc: 'ページ末尾へジャンプ。', opts: [] },

  // Navigation
  { id: 'goBack',    name: 'goBack',    cat: 'nav', desc: 'history.back() を呼ぶ。', opts: [] },
  { id: 'goForward', name: 'goForward', cat: 'nav', desc: 'history.forward() を呼ぶ。', opts: [] },
  { id: 'reload',    name: 'reload',    cat: 'nav',
    desc: '現在のページを再読み込み。',
    opts: [{ key: 'hard', type: 'boolean', default: false }] },
  { id: 'goToParent', name: 'goToParent', cat: 'nav',
    desc: 'URL のパスを 1 つ上へ移動。', opts: [] },
  { id: 'goToRoot',   name: 'goToRoot',   cat: 'nav',
    desc: 'URL のルート (/) へ移動。', opts: [] },

  // Tabs
  { id: 'nextTab',     name: 'nextTab',     cat: 'tab',
    desc: '次のタブをアクティブ化。',
    opts: [{ key: 'wrap', type: 'boolean', default: true }] },
  { id: 'prevTab',     name: 'prevTab',     cat: 'tab',
    desc: '前のタブをアクティブ化。',
    opts: [{ key: 'wrap', type: 'boolean', default: true }] },
  { id: 'closeTab',    name: 'closeTab',    cat: 'tab', desc: '現在のタブを閉じる。', opts: [] },
  { id: 'reopenTab',   name: 'reopenTab',   cat: 'tab',
    desc: '直前に閉じたタブを復元。', opts: [] },
  { id: 'duplicateTab',name: 'duplicateTab',cat: 'tab', desc: '現在のタブを複製。', opts: [] },
  { id: 'pinTab',      name: 'pinTab',      cat: 'tab', desc: 'タブのピン留めを切替。', opts: [] },
  { id: 'newTab',      name: 'newTab',      cat: 'tab',
    desc: '新しいタブを開く。url 未指定なら新規タブページ。',
    opts: [{ key: 'url', type: 'string', default: '' }] },

  // Focus / Hints
  { id: 'showHints',     name: 'showHints',     cat: 'focus',
    desc: 'クリック可能要素にヒントラベルを重ねる。',
    opts: [
      { key: 'mode', type: 'select', default: 'click',
        choices: ['click', 'newTab', 'copy', 'hover'] },
      { key: 'characters', type: 'string', default: 'sadfjklewcmpgh' },
    ] },
  { id: 'focusInput',    name: 'focusInput',    cat: 'focus',
    desc: 'ページ内の最初の入力フィールドにフォーカス。', opts: [] },
  { id: 'blurFocus',     name: 'blurFocus',     cat: 'focus',
    desc: '現在フォーカス中の要素から外す (Esc 相当)。', opts: [] },

  // Find
  { id: 'findInPage',    name: 'findInPage',    cat: 'find',
    desc: 'ページ内検索バーを開く。', opts: [] },
  { id: 'findNext',      name: 'findNext',      cat: 'find',
    desc: '次の検索結果へ移動。', opts: [] },
  { id: 'findPrev',      name: 'findPrev',      cat: 'find',
    desc: '前の検索結果へ移動。', opts: [] },

  // Forms
  { id: 'submitForm',    name: 'submitForm',    cat: 'form',
    desc: 'フォーカス中のフォームを送信。', opts: [] },
  { id: 'copyURL',       name: 'copyURL',       cat: 'form',
    desc: '現在の URL をクリップボードへコピー。', opts: [] },

  // Site-specific — search-result navigation. site can be a single id or array
  // for actions that apply to multiple services (e.g. Google + Yahoo).
  { id: 'focusNextResult', name: 'focusNextResult', cat: 'site', site: ['google', 'yahoo'],
    desc: '検索結果の次の項目へフォーカス。Google / Yahoo の両方で動作。',
    opts: [{ key: 'wrap', type: 'boolean', default: false }] },
  { id: 'focusPrevResult', name: 'focusPrevResult', cat: 'site', site: ['google', 'yahoo'],
    desc: '検索結果の前の項目へフォーカス。Google / Yahoo の両方で動作。',
    opts: [{ key: 'wrap', type: 'boolean', default: false }] },
  { id: 'openResult', name: 'openResult', cat: 'site', site: ['google', 'yahoo'],
    desc: 'フォーカス中の検索結果を開く。',
    opts: [{ key: 'newTab', type: 'boolean', default: false }] },
  { id: 'switchSearchTab', name: 'switchSearchTab', cat: 'site', site: 'google',
    desc: 'Google の検索カテゴリ (画像 / 動画 / ニュース…) を切替。',
    opts: [{ key: 'tab', type: 'select', default: 'all',
            choices: ['all', 'images', 'videos', 'news', 'maps'] }] },

  // Site-specific (GitHub)
  { id: 'focusFile', name: 'focusFile', cat: 'site', site: 'github',
    desc: 'リポジトリのファイルツリーで次のファイルへフォーカス。', opts: [] },
  { id: 'openPRList', name: 'openPRList', cat: 'site', site: 'github',
    desc: '同リポジトリの Pull Requests 一覧へ移動。', opts: [] },
  { id: 'openIssues', name: 'openIssues', cat: 'site', site: 'github',
    desc: '同リポジトリの Issues 一覧へ移動。', opts: [] },
  { id: 'gotoCode', name: 'gotoCode', cat: 'site', site: 'github',
    desc: 'リポジトリの Code タブへ戻る。', opts: [] },

  // Site-specific (YouTube)
  { id: 'togglePlay', name: 'togglePlay', cat: 'site', site: 'youtube',
    desc: '再生 / 一時停止を切替。', opts: [] },
  { id: 'seekForward', name: 'seekForward', cat: 'site', site: 'youtube',
    desc: '指定秒だけ早送り。',
    opts: [{ key: 'seconds', type: 'number', default: 5, unit: 's' }] },
  { id: 'seekBackward', name: 'seekBackward', cat: 'site', site: 'youtube',
    desc: '指定秒だけ巻き戻し。',
    opts: [{ key: 'seconds', type: 'number', default: 5, unit: 's' }] },
];

// Sites the extension supports. (User does not add arbitrary domains.)
const SERVICES = [
  { id: 'google',  name: 'Google',  domain: 'google.com',  color: '#4285f4', initials: 'G' },
  { id: 'yahoo',   name: 'Yahoo',   domain: 'yahoo.co.jp', color: '#7e1fff', initials: 'Y!' },
  { id: 'github',  name: 'GitHub',  domain: 'github.com',  color: '#1f1f1f', initials: 'Gh' },
  { id: 'youtube', name: 'YouTube', domain: 'youtube.com', color: '#ff0033', initials: 'Y' },
  { id: 'reddit',  name: 'Reddit',  domain: 'reddit.com',  color: '#ff4500', initials: 'R' },
  { id: 'twitter', name: 'X / Twitter', domain: 'x.com',  color: '#000000', initials: 'X' },
];

const PRESETS = [
  { id: 'vim-like', name: 'vim-like',
    tag: 'recommended',
    desc: 'Vimium 風。j/k で行スクロール、d/u で半ページ、gg/G で先頭末尾、t/T でタブ移動。',
    keys: ['j', 'k', 'd', 'u', 'gg', 'G', 't', 'T', 'h', 'l', 'r', 'x'],
    bindingCount: 24 },
  { id: 'wsn-like', name: 'web-search-navigator-like',
    tag: 'compact',
    desc: '検索結果を矢印キーで上下移動、Enter で開く。Google を中心に最小構成。',
    keys: ['↓', '↑', '↵', 'n', 'p', 'o', 'c'],
    bindingCount: 11 },
  { id: 'arrows',   name: 'arrows-only',
    tag: 'beginner',
    desc: '矢印キー + Esc を中心とした最小セット。修飾キー不要、初めての設定向け。',
    keys: ['↑', '↓', '←', '→', 'Esc', 'Enter'],
    bindingCount: 8 },
  { id: 'mac-like', name: 'mac-system-like',
    tag: 'minimal',
    desc: '⌘ + 数字でタブ切替、⌘W で閉じる、⌘L で URL バー。',
    keys: ['⌘ 1', '⌘ 2', '⌘ W', '⌘ L', '⌘ T', '⌘ R'],
    bindingCount: 9 },
];

// QWERTY + Dvorak (US) — for the keyboard visualization.
// Each entry: code (logical key id used in bindings), label (visible character).
const KEYBOARD_LAYOUTS = {
  qwerty: [
    [{c:'`'}, {c:'1'}, {c:'2'}, {c:'3'}, {c:'4'}, {c:'5'}, {c:'6'}, {c:'7'}, {c:'8'}, {c:'9'}, {c:'0'}, {c:'-'}, {c:'='}, {c:'⌫', w:'wider'}],
    [{c:'⇥', w:'wide'}, {c:'q'}, {c:'w'}, {c:'e'}, {c:'r'}, {c:'t'}, {c:'y'}, {c:'u'}, {c:'i'}, {c:'o'}, {c:'p'}, {c:'['}, {c:']'}, {c:'\\'}],
    [{c:'⇪', w:'wide'}, {c:'a'}, {c:'s'}, {c:'d'}, {c:'f'}, {c:'g'}, {c:'h'}, {c:'j'}, {c:'k'}, {c:'l'}, {c:';'}, {c:'\''}, {c:'↵', w:'wider'}],
    [{c:'⇧', w:'wider'}, {c:'z'}, {c:'x'}, {c:'c'}, {c:'v'}, {c:'b'}, {c:'n'}, {c:'m'}, {c:','}, {c:'.'}, {c:'/'}, {c:'⇧', w:'wider'}],
  ],
  dvorak: [
    [{c:'`'}, {c:'1'}, {c:'2'}, {c:'3'}, {c:'4'}, {c:'5'}, {c:'6'}, {c:'7'}, {c:'8'}, {c:'9'}, {c:'0'}, {c:'['}, {c:']'}, {c:'⌫', w:'wider'}],
    [{c:'⇥', w:'wide'}, {c:'\''}, {c:','}, {c:'.'}, {c:'p'}, {c:'y'}, {c:'f'}, {c:'g'}, {c:'c'}, {c:'r'}, {c:'l'}, {c:'/'}, {c:'='}, {c:'\\'}],
    [{c:'⇪', w:'wide'}, {c:'a'}, {c:'o'}, {c:'e'}, {c:'u'}, {c:'i'}, {c:'d'}, {c:'h'}, {c:'t'}, {c:'n'}, {c:'s'}, {c:'-'}, {c:'↵', w:'wider'}],
    [{c:'⇧', w:'wider'}, {c:';'}, {c:'q'}, {c:'j'}, {c:'k'}, {c:'x'}, {c:'b'}, {c:'m'}, {c:'w'}, {c:'v'}, {c:'z'}, {c:'⇧', w:'wider'}],
  ],
};

// Sample seed bindings — Global has the bulk, GitHub & YouTube have a few each.
// Conflicts intentional in Global (`x` mapped twice) so the warning UI has content.
let __id = 0;
const b = (triggers, action, opts = {}) => ({
  id: 'b' + (++__id),
  triggers,
  action,
  opts,
});

const initialBindings = {
  global: [
    b([['j']], 'scrollDown',     { amount: 100, inertia: false }),
    b([['k']], 'scrollUp',       { amount: 100, inertia: false }),
    b([['J']], 'scrollDown',     { amount: 500, inertia: true }),
    b([['K']], 'scrollUp',       { amount: 500, inertia: true }),
    b([['d']], 'scrollPageDown', { overlap: 40 }),
    b([['u']], 'scrollPageUp',   { overlap: 40 }),
    b([['g','g']], 'scrollToTop', {}),
    b([['G']], 'scrollToBottom', {}),
    b([['h'], ['ArrowLeft']], 'goBack', {}),
    b([['l'], ['ArrowRight']], 'goForward', {}),
    b([['r']], 'reload', { hard: false }),
    b([['t']], 'nextTab',  { wrap: true }),
    b([['T']], 'prevTab',  { wrap: true }),
    b([['x']], 'closeTab', {}),
    // intentional conflict — same trigger as closeTab
    b([['x']], 'duplicateTab', {}),
    b([['X']], 'reopenTab', {}),
    b([['f']], 'showHints', { mode: 'click', characters: 'sadfjklewcmpgh' }),
    b([['F']], 'showHints', { mode: 'newTab', characters: 'sadfjklewcmpgh' }),
    b([['Escape']], 'blurFocus', {}),
    b([['/']], 'findInPage', {}),
    b([['n']], 'findNext', {}),
    b([['N']], 'findPrev', {}),
    b([['y','y']], 'copyURL', {}),
    b([['<C-r>']], 'reload', { hard: true }),
    b([['<C-S-T>']], 'reopenTab', {}),
    b([['<M-k>'], ['<C-k>']], 'showHints', { mode: 'click', characters: 'sadfjklewcmpgh' }),
  ],
  google: [
    b([['j'], ['ArrowDown']], 'focusNextResult', { wrap: false }),
    b([['k'], ['ArrowUp']], 'focusPrevResult', { wrap: false }),
    b([['Enter']], 'openResult', { newTab: false }),
    b([['o']], 'openResult', { newTab: true }),
    b([['1']], 'switchSearchTab', { tab: 'all' }),
    b([['2']], 'switchSearchTab', { tab: 'images' }),
    b([['3']], 'switchSearchTab', { tab: 'videos' }),
  ],
  github: [
    b([['g','c']], 'gotoCode', {}),
    b([['g','i']], 'openIssues', {}),
    b([['g','p']], 'openPRList', {}),
    b([['t']], 'focusFile', {}),
  ],
  youtube: [
    b([['k'], [' ']], 'togglePlay', {}),
    b([['l']], 'seekForward', { seconds: 10 }),
    b([['j']], 'seekBackward', { seconds: 10 }),
  ],
  reddit: [],
  twitter: [],
  yahoo: [],
};

Object.assign(window, {
  ACTIONS, CATEGORIES, SERVICES, PRESETS,
  initialBindings, KEYBOARD_LAYOUTS,
});
