// page-navigator — sidebar.
// Two groups: Global (pinned, single row, not draggable) and Sites
// (draggable list + "Add site" button). System actions in a footer group.

const { useState: __ssState } = React;

function Sidebar({ scope, setScope, view, setView,
                   bindingCounts, conflictCounts,
                   siteOrder, onReorderSites, onShowAddSite,
                   onShowImport, onShowExport, onShowReference,
                   onShowPreferences }) {
  const [dragId, setDragId] = __ssState(null);
  const [overId, setOverId] = __ssState(null);
  const [overPos, setOverPos] = __ssState(null);

  const visibleSites = siteOrder
    .map((id) => SERVICES.find((s) => s.id === id))
    .filter(Boolean);

  const onDragStart = (e, id) => {
    setDragId(id);
    try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/site', id); } catch {}
  };
  const onDragOver = (e, id) => {
    if (!dragId || dragId === id) return;
    e.preventDefault();
    const r = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientY - r.top) < r.height / 2 ? 'before' : 'after';
    setOverId(id); setOverPos(pos);
  };
  const onDrop = (e) => {
    if (!dragId || !overId || dragId === overId) {
      setDragId(null); setOverId(null); setOverPos(null);
      return;
    }
    e.preventDefault();
    const next = siteOrder.filter((id) => id !== dragId);
    const idx = next.indexOf(overId);
    next.splice(overPos === 'after' ? idx + 1 : idx, 0, dragId);
    onReorderSites(next);
    setDragId(null); setOverId(null); setOverPos(null);
  };
  const onDragEnd = () => { setDragId(null); setOverId(null); setOverPos(null); };

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-mark">pn</div>
        <div className="brand-name">page-navigator</div>
        <span className="brand-state">on</span>
      </div>

      {/* Global — pinned, lives on its own with no group label */}
      <div className="side-global">
        <div className={'side-item global' + (scope === 'global' && view !== 'reference' ? ' active' : '')}
             onClick={() => { setScope('global'); setView('edit'); }}>
          <span className="side-icon"><Icon name="globe" /></span>
          <span className="side-label">Global</span>
          {conflictCounts.global > 0 && (
            <span className="side-conflict" title={`${conflictCounts.global} conflicts`} />
          )}
          <span className="side-count">{bindingCounts.global || 0}</span>
        </div>
      </div>

      {/* Sites — labeled group with its own list */}
      <div className="side-group">
        <div className="side-group-h">
          <span className="ttl">Sites</span>
          <button className="side-group-add" onClick={onShowAddSite} title="サイトを追加">
            <Icon name="plus" size={12} />
          </button>
        </div>
        <nav className="side-list">
          {visibleSites.length === 0 && (
            <button className="side-empty" onClick={onShowAddSite}>
              <Icon name="plus" size={11} /> Add a site
            </button>
          )}
          {visibleSites.map((s) => {
            const isDragging = dragId === s.id;
            const isOver = overId === s.id;
            return (
              <div key={s.id}
                   className={'side-item site'
                     + (scope === s.id && view !== 'reference' ? ' active' : '')
                     + (isDragging ? ' dragging' : '')
                     + (isOver ? (' drop-' + overPos) : '')}
                   draggable="true"
                   onDragStart={(e) => onDragStart(e, s.id)}
                   onDragOver={(e) => onDragOver(e, s.id)}
                   onDrop={onDrop}
                   onDragEnd={onDragEnd}
                   onClick={() => { setScope(s.id); setView('edit'); }}>
                <span className="side-grip" title="ドラッグして並び替え"><Icon name="grip" size={12} /></span>
                <SiteFav service={s} />
                <span className="side-label">{s.name}</span>
                {conflictCounts[s.id] > 0 && (
                  <span className="side-conflict" title={`${conflictCounts[s.id]} conflicts`} />
                )}
                <span className="side-count">{bindingCounts[s.id] || 0}</span>
              </div>
            );
          })}
        </nav>
      </div>

      <div className="side-spacer" />

      <div className="side-system">
        <div className={'side-item' + (view === 'reference' ? ' active' : '')}
             onClick={onShowReference}>
          <span className="side-icon"><Icon name="book" /></span>
          <span className="side-label">Reference</span>
        </div>
        <div className="side-item" onClick={onShowImport}>
          <span className="side-icon"><Icon name="import" /></span>
          <span className="side-label">Import…</span>
        </div>
        <div className="side-item" onClick={onShowExport}>
          <span className="side-icon"><Icon name="export" /></span>
          <span className="side-label">Export…</span>
        </div>
        <div className={'side-item' + (view === 'preferences' ? ' active' : '')}
             onClick={onShowPreferences}>
          <span className="side-icon"><Icon name="gear" /></span>
          <span className="side-label">Preferences</span>
        </div>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
