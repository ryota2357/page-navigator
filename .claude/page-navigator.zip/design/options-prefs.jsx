/* Preferences view — keeps the live extension's content but redrawn to
   sit inside the constrained container. */

function PreferencesView({ timeoutMs, onChangeTimeout }) {
  const min = 200, max = 5000;
  const bar = Math.min(100, Math.max(0, ((timeoutMs - min) / (max - min)) * 100));
  const [draft, setDraft] = React.useState("");
  const [patterns, setPatterns] = React.useState(["mail.google.com/*"]);

  function addPattern() {
    const t = draft.trim();
    if (!t || patterns.includes(t)) return;
    setPatterns([...patterns, t]);
    setDraft("");
  }
  function removePattern(p) {
    setPatterns(patterns.filter((x) => x !== p));
  }

  return (
    <>
      <div className="prefs-head">
        <h1>Preferences</h1>
        <p>Global runtime settings — apply across every scope.</p>
      </div>

      <div className="prefs-sections">
        <section className="prefs-section">
          <div className="prefs-row">
            <div className="prefs-label">
              <div className="title">Sequence timeout</div>
              <div className="desc">
                How long to wait for the next key in a multi-key sequence (e.g.
                <code>g g</code>). Clamped to {min}–{max} ms.
              </div>
            </div>
            <div className="num-wrap">
              <input
                type="number"
                min={min}
                max={max}
                step={50}
                value={timeoutMs}
                onChange={(e) => onChangeTimeout(Number(e.target.value))}
              />
              <span className="unit">ms</span>
            </div>
          </div>
          <div className="timeout-preview">
            <span className="timeout-bar-label">0</span>
            <div className="timeout-bar" style={{ "--bar": bar + "%" }} />
            <span className="timeout-bar-label">{timeoutMs}ms</span>
          </div>
        </section>

        <section className="prefs-section">
          <div className="prefs-row stack">
            <div className="prefs-label">
              <div className="title">Disabled pages</div>
              <div className="desc">
                URLs matching these patterns will ignore page-navigator key presses.
                Use <code>*</code> as a wildcard.
              </div>
            </div>
            <div className="pattern-input">
              <input
                type="text"
                placeholder="e.g. mail.google.com/*"
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addPattern())}
              />
              <button type="button" className="add-mini" onClick={addPattern}>Add</button>
            </div>
            {patterns.length > 0 && (
              <ul className="pattern-rows">
                {patterns.map((p) => (
                  <li key={p} className="pattern-row">
                    <code className="ptext">{p}</code>
                    <button
                      type="button"
                      onClick={() => removePattern(p)}
                      style={{ appearance: "none", border: 0, background: "transparent", width: 22, height: 22, borderRadius: 4, color: "var(--text-4)", display: "grid", placeItems: "center", cursor: "default" }}
                      onMouseEnter={(e) => { e.currentTarget.style.background = "var(--danger-bg)"; e.currentTarget.style.color = "var(--danger)"; }}
                      onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--text-4)"; }}
                    >
                      <Icon name="trash" size={12} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
        <section className="prefs-section">
          <div className="prefs-row stack">
            <div className="prefs-label">
              <div className="title">Backup</div>
              <div className="desc">
                Export the full binding set as JSON for backup or sharing, or
                import a previously-exported file. Import replaces the current
                binding set; preview the diff before confirming.
              </div>
            </div>
            <div className="prefs-actions">
              <button type="button" className="prefs-btn">
                <Icon name="import" size={13} /> Import…
              </button>
              <button type="button" className="prefs-btn">
                <Icon name="export" size={13} /> Export…
              </button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

Object.assign(window, { PreferencesView });
