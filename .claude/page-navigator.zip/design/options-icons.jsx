/* Icon set lifted from src/entrypoints/options/components/Icon.svelte
   — only the names this redesign actually uses. */

function Icon({ name, size = 14 }) {
  const props = {
    width: size, height: size,
    viewBox: "0 0 16 16", fill: "none",
    "aria-hidden": "true",
  };
  switch (name) {
    case "globe":
      return (
        <svg {...props}>
          <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5" />
          <path d="M2 8h12M8 2c2 1.8 3 4 3 6s-1 4.2-3 6c-2-1.8-3-4-3-6s1-4.2 3-6Z" stroke="currentColor" strokeWidth="1.5" />
        </svg>
      );
    case "search":
      return (
        <svg {...props}>
          <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
          <path d="m10.5 10.5 3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case "plus":
      return (
        <svg {...props}>
          <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case "down":
      return (
        <svg {...props}>
          <path d="m4 6 4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "import":
      return (
        <svg {...props}>
          <path d="M8 3v7M5 7l3 3 3-3M3 11v1a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "export":
      return (
        <svg {...props}>
          <path d="M8 10V3M5 6l3-3 3 3M3 11v1a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "trash":
      return (
        <svg {...props}>
          <path d="M3 4.5h10M5.5 4.5V3a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1.5M4 4.5v8.5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.5M7 7v4M9 7v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case "gear":
      return (
        <svg {...props}>
          <circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.5" />
          <path d="M8 2v1.6M8 12.4V14M2 8h1.6M12.4 8H14M3.8 3.8l1.1 1.1M11.1 11.1l1.1 1.1M3.8 12.2l1.1-1.1M11.1 4.9l1.1-1.1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case "grip":
      return (
        <svg {...props} fill="currentColor">
          <circle cx="6" cy="4" r="1.1" />
          <circle cx="10" cy="4" r="1.1" />
          <circle cx="6" cy="8" r="1.1" />
          <circle cx="10" cy="8" r="1.1" />
          <circle cx="6" cy="12" r="1.1" />
          <circle cx="10" cy="12" r="1.1" />
        </svg>
      );
    case "eye":
      return (
        <svg {...props}>
          <path d="M1.5 8s2.5-4.5 6.5-4.5S14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
          <circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.5" />
        </svg>
      );
    case "eye-off":
      return (
        <svg {...props}>
          <path d="M3 3l10 10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M6 5.4C6.6 5.1 7.3 5 8 5c4 0 6.5 3 6.5 3S13.6 9.3 12 10.4M10.2 11C9.5 11.2 8.8 11.3 8 11.3c-4 0-6.5-3-6.5-3S3 6.8 4.6 5.7" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
        </svg>
      );
    case "warn":
      return (
        <svg {...props}>
          <path d="M8 2 1.5 13.5h13L8 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M8 6.5v3.5M8 12v.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}

Object.assign(window, { Icon });
