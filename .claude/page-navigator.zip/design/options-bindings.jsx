/* Bindings view — header + toolbar + list of rows.
   `enableMode` controls the enable/disable UX:
     - "toggle"  : compact switch in a leading cell. Disabled rows dimmed.
     - "eye"     : eye/eye-off button next to the row grip. Disabled rows dimmed.
     - "badge"   : no per-row affordance; enable lives in the edit panel,
                   list shows a quiet "OFF" badge in the trigger column.
*/

function KeyTag({ keys, conflict, removable }) {
  return (
    <span className={"tkey" + (conflict ? " conflict" : "")}>
      {keys.map((k, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span className="tkey-plus">·</span>}
          <span>{k}</span>
        </React.Fragment>
      ))}
      {removable && (
        <button
          type="button"
          className="tkey-x"
          aria-label="Remove trigger"
          onClick={(e) => e.stopPropagation()}
        >
          ×
        </button>
      )}
    </span>
  );
}

function BindingRow({ binding, action, editing, onStartEdit, onCommit, onCancel, onToggleEnabled, enableMode, density }) {
  const disabled = !binding.enabled;
  const rowClass = [
    "row",
    editing ? "editing" : "",
    disabled ? "disabled" : "",
    "mode-" + enableMode,
    binding.conflict ? "conflict" : "",
  ].filter(Boolean).join(" ");

  const leadCell = (
    <div className="cell-enable">
      {enableMode === "toggle" && (
        <button
          type="button"
          className={"enable-toggle" + (binding.enabled ? " on" : "")}
          title={binding.enabled ? "Disable this binding" : "Enable this binding"}
          onClick={(e) => { e.stopPropagation(); onToggleEnabled(); }}
          aria-pressed={binding.enabled}
        />
      )}
    </div>
  );

  return (
    <div className={rowClass} onClick={editing ? undefined : onStartEdit} data-id={binding.id}>
      {leadCell}

      <div className="cell-trigger">
        {enableMode === "badge" && disabled && !editing && (
          <span className="off-badge">off</span>
        )}
        {binding.triggers.map((t, i) => (
          <KeyTag
            key={i}
            keys={t}
            conflict={binding.conflict}
            removable={editing}
          />
        ))}
        {editing && (
          <button
            type="button"
            className="add-key"
            onClick={(e) => e.stopPropagation()}
          >
            <Icon name="plus" size={10} /> add key
          </button>
        )}
      </div>

      <div className="cell-action">
        {editing ? (
          <button
            type="button"
            className="action-picker"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="action-name">
              {action.name}
              {action.badge && <span className="badge site">{action.badge}</span>}
            </span>
            <span className="chev"><Icon name="down" size={10} /></span>
          </button>
        ) : (
          <span className="action-name">
            {action.name}
            {action.badge && <span className="badge site">{action.badge}</span>}
          </span>
        )}
        {density !== "compact" && (
          <span className="action-desc">{action.desc}</span>
        )}
      </div>

      <div className="cell-options">
        {editing ? (
          Object.keys(binding.options ?? {}).length === 0 ? (
            <span className="muted">—</span>
          ) : (
            Object.entries(binding.options).map(([k, v]) => (
              <label key={k} className="opt-edit">
                <span className="opt-key">{k}</span>
                {typeof v === "boolean" ? (
                  <span className={"opt-switch" + (v ? " on" : "")} />
                ) : (
                  <input
                    type={typeof v === "number" ? "number" : "text"}
                    defaultValue={String(v)}
                    onClick={(e) => e.stopPropagation()}
                  />
                )}
              </label>
            ))
          )
        ) : (
          Object.keys(binding.options ?? {}).length === 0 ? (
            <span className="muted">—</span>
          ) : (
            Object.entries(binding.options).map(([k, v]) => (
              <span key={k} className="opt">
                <span className="opt-key">{k}</span>
                <span className="opt-val">{typeof v === "boolean" ? (v ? "true" : "false") : String(v)}</span>
              </span>
            ))
          )
        )}
      </div>

      <div className="cell-handle">
        {enableMode === "eye" && !editing && (
          <button
            type="button"
            className={"enable-eye" + (disabled ? " off" : "")}
            title={disabled ? "Enable this binding" : "Disable this binding"}
            onClick={(e) => { e.stopPropagation(); onToggleEnabled(); }}
          >
            <Icon name={disabled ? "eye-off" : "eye"} size={14} />
          </button>
        )}
        {!editing && (
          <span className="grip-row" onClick={(e) => e.stopPropagation()}>
            <Icon name="grip" size={14} />
          </span>
        )}
      </div>

      {editing && (
        <div className="edit-actions" onClick={(e) => e.stopPropagation()}>
          <button type="button" className="btn ghost danger">
            <Icon name="trash" size={12} /> Delete
          </button>
          <label className="toggle-inline">
            <button
              type="button"
              className={"enable-toggle" + (binding.enabled ? " on" : "")}
              onClick={(e) => { e.stopPropagation(); onToggleEnabled(); }}
              aria-pressed={binding.enabled}
            />
            <span>{binding.enabled ? "Enabled" : "Disabled"}</span>
          </label>
          <span className="edit-spacer" />
          <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>
          <button type="button" className="btn primary" onClick={onCommit}>Done</button>
        </div>
      )}
    </div>
  );
}

function BindingsView({ scope, enableMode, density, showDisabled, onToggleShowDisabled, editingId, onStartEdit, onCancelEdit, bindings, onToggleEnabled }) {
  const scopeLabels = {
    global: { title: "Global", initial: null, color: null, desc: "Active on every page. Site-specific bindings, when set, take priority over Global." },
    google: { title: "Google", initial: "G", color: "#4285F4", desc: "Active only on Google pages. Overrides Global where triggers overlap." },
    github: { title: "GitHub", initial: "GH", color: "#24292f", desc: "Active only on GitHub pages. Overrides Global where triggers overlap." },
  };
  const meta = scopeLabels[scope] ?? scopeLabels.global;

  const filtered = showDisabled ? bindings : bindings.filter((b) => b.enabled);
  const conflictCount = bindings.filter((b) => b.conflict).length;
  const disabledCount = bindings.filter((b) => !b.enabled).length;

  return (
    <>
      <div className="head">
        <div className="head-icon">
          {meta.initial ? (
            <span className="fav-lg" style={{ background: meta.color }}>{meta.initial}</span>
          ) : (
            <span className="globe-lg"><Icon name="globe" size={16} /></span>
          )}
        </div>
        <div className="head-text">
          <h1>{meta.title}</h1>
          <p>{meta.desc}</p>
        </div>
        <div className="head-meta">
          <span>
            {bindings.length} binding{bindings.length === 1 ? "" : "s"}
            {disabledCount > 0 && <> · <span style={{ color: "var(--text-3)" }}>{disabledCount} disabled</span></>}
            {conflictCount > 0 && <> · <span className="danger">{conflictCount} conflict{conflictCount === 1 ? "" : "s"}</span></>}
          </span>
        </div>
      </div>

      <div className="toolbar">
        <div className="search">
          <Icon name="search" size={14} />
          <input type="text" placeholder="Filter by trigger or action…" />
        </div>
        <span className="tbar-sp" />
        <label className={"show-disabled" + (showDisabled ? " on" : "")}>
          <input type="checkbox" checked={showDisabled} onChange={onToggleShowDisabled} />
          <Icon name={showDisabled ? "eye" : "eye-off"} size={13} />
          {showDisabled ? "Showing disabled" : "Hide disabled"}
          {disabledCount > 0 && <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>({disabledCount})</span>}
        </label>
        <button type="button" className="add-btn">
          <Icon name="plus" size={13} /> New binding
        </button>
      </div>

      {conflictCount > 0 && (
        <div className="banner" style={{ margin: "0 0 10px" }}>
          <Icon name="warn" size={14} />
          {conflictCount} trigger{conflictCount === 1 ? "" : "s"} clash in this scope. The first match wins; the rest never fire.
          <button type="button" className="jump">Jump to first</button>
        </div>
      )}

      <div className="list">
        {filtered.map((b) => (
          <BindingRow
            key={b.id}
            binding={b}
            action={window.sampleActions[b.actionId]}
            editing={editingId === b.id}
            onStartEdit={() => onStartEdit(b.id)}
            onCommit={() => onCancelEdit()}
            onCancel={() => onCancelEdit()}
            onToggleEnabled={() => onToggleEnabled(b.id)}
            enableMode={enableMode}
            density={density}
          />
        ))}
        {filtered.length === 0 && (
          <div style={{ padding: "32px 16px", textAlign: "center", color: "var(--text-3)", fontSize: 12.5 }}>
            All bindings in this scope are disabled. Toggle "Showing disabled" to reveal them.
          </div>
        )}
      </div>
    </>
  );
}

Object.assign(window, { BindingsView, BindingRow, KeyTag });
