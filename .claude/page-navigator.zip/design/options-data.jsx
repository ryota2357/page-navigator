/* Sample data — fictional bindings that resemble what a vim-like
   navigator extension's options page would show. */

const sampleActions = {
  "scroll.down":            { name: "scroll.down",            desc: "Scroll the page down by one line." },
  "scroll.up":              { name: "scroll.up",              desc: "Scroll the page up by one line." },
  "scroll.halfPageDown":    { name: "scroll.halfPageDown",    desc: "Scroll down by half the viewport height." },
  "scroll.halfPageUp":      { name: "scroll.halfPageUp",      desc: "Scroll up by half the viewport height." },
  "scroll.top":             { name: "scroll.top",             desc: "Jump to the top of the page." },
  "scroll.bottom":          { name: "scroll.bottom",          desc: "Jump to the bottom of the page." },
  "tab.next":               { name: "tab.next",               desc: "Switch to the next browser tab." },
  "tab.prev":               { name: "tab.prev",               desc: "Switch to the previous browser tab." },
  "tab.close":              { name: "tab.close",              desc: "Close the current tab." },
  "link.followNew":         { name: "link.followNew",         desc: "Open the focused link in a new background tab." },
  "search.focus":           { name: "search.focus",           desc: "Focus the in-page search box.", badge: "google" },
  "search.nextResult":      { name: "search.nextResult",      desc: "Jump to the next result link.", badge: "google" },
  "search.prevResult":      { name: "search.prevResult",      desc: "Jump to the previous result link.", badge: "google" },
};

const sampleBindings = {
  global: [
    { id: "b1", triggers: [["j"]],              actionId: "scroll.down",         options: { lines: 3 },          enabled: true,  conflict: false },
    { id: "b2", triggers: [["k"]],              actionId: "scroll.up",           options: { lines: 3 },          enabled: true,  conflict: false },
    { id: "b3", triggers: [["d"]],              actionId: "scroll.halfPageDown", options: {},                     enabled: true,  conflict: false },
    { id: "b4", triggers: [["u"]],              actionId: "scroll.halfPageUp",   options: {},                     enabled: true,  conflict: false },
    { id: "b5", triggers: [["g","g"]],          actionId: "scroll.top",          options: { smooth: true },       enabled: true,  conflict: false },
    { id: "b6", triggers: [["Shift+g"]],        actionId: "scroll.bottom",       options: { smooth: true },       enabled: true,  conflict: false },
    { id: "b7", triggers: [["Ctrl+Tab"], ["L"]],actionId: "tab.next",            options: {},                     enabled: true,  conflict: false },
    { id: "b8", triggers: [["Ctrl+Shift+Tab"], ["H"]], actionId: "tab.prev",     options: {},                     enabled: false, conflict: false },
    { id: "b9", triggers: [["x"]],              actionId: "tab.close",           options: { confirm: false },     enabled: false, conflict: false },
    { id: "b10", triggers: [["F"]],             actionId: "link.followNew",      options: {},                     enabled: true,  conflict: false },
  ],
  google: [
    { id: "g1", triggers: [["/"]],              actionId: "search.focus",        options: {},                     enabled: true,  conflict: false },
    { id: "g2", triggers: [["n"]],              actionId: "search.nextResult",   options: { wrap: true },         enabled: true,  conflict: true  },
    { id: "g3", triggers: [["p"]],              actionId: "search.prevResult",   options: { wrap: true },         enabled: true,  conflict: true  },
    { id: "g4", triggers: [["j"]],              actionId: "scroll.down",         options: { lines: 1 },           enabled: true,  conflict: false },
    { id: "g5", triggers: [["g","s"]],          actionId: "search.focus",        options: {},                     enabled: false, conflict: false },
  ],
};

const sampleSites = [
  { id: "global", label: "Global" },
  { id: "google", label: "Google" },
  { id: "github", label: "GitHub" },
];

Object.assign(window, { sampleActions, sampleBindings, sampleSites });
