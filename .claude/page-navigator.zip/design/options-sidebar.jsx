/* Sidebar — same shape as the live extension, minus the Reference entry.
   Counts are sourced from sampleBindings. */

function Sidebar({
  selectedScope, view,
  onSelectScope, onShowPrefs, onShowImport, onShowExport,
  settingsLocation = "list",
}) {
  const counts = {};
  const conflicts = {};
  for (const [scope, list] of Object.entries(window.sampleBindings)) {
    counts[scope] = list.length;
    conflicts[scope] = list.filter((b) => b.conflict).length;
  }
  const sites = [
    { id: "google", label: "Google", initials: "G", color: "#4285F4" },
    { id: "github", label: "GitHub", initials: "GH", color: "#24292f" },
  ];
  const globalActive = view === "edit" && selectedScope === "global";
  const showHeaderActions = settingsLocation === "header";
  const showListSection  = settingsLocation === "list";

  return (
    <aside className={"sidebar settings-" + settingsLocation}>
      <div className="brand">
        <div className="mark">pn</div>
        <div className="name">page-navigator</div>
        <span className="state">on</span>
        {showHeaderActions && (
          <span className="header-actions">
            <button
              type="button"
              className={"header-action" + (view === "preferences" ? " active" : "")}
              onClick={onShowPrefs}
              title="Preferences"
            >
              <Icon name="gear" size={13} />
            </button>
          </span>
        )}
      </div>

      <div className="group global">
        <button
          type="button"
          className={"item global-item" + (globalActive ? " active" : "")}
          onClick={() => onSelectScope("global")}
        >
          <span className="icon"><Icon name="globe" /></span>
          <span className="label">Global</span>
          {conflicts.global > 0 && <span className="conflict-dot" />}
          <span className="count">{counts.global ?? 0}</span>
        </button>
      </div>

      <div className="group">
        <div className="group-head">
          <span className="group-title">Sites</span>
          <button type="button" className="group-add" title="Add a site">
            <Icon name="plus" size={12} />
          </button>
        </div>
        <nav className="site-list">
          {sites.map((site) => {
            const active = view === "edit" && selectedScope === site.id;
            return (
              <div
                key={site.id}
                role="button"
                className={"item site" + (active ? " active" : "")}
                onClick={() => onSelectScope(site.id)}
              >
                <span className="grip-side"><Icon name="grip" size={12} /></span>
                <span className="fav" style={{ background: site.color }}>{site.initials}</span>
                <span className="label">{site.label}</span>
                {conflicts[site.id] > 0 && <span className="conflict-dot" />}
                <span className="count">{counts[site.id] ?? 0}</span>
              </div>
            );
          })}
        </nav>
      </div>

      <div className="spacer" />

      {showListSection && (
        <div className="footer">
          <span className="footer-title">Settings</span>
          <button
            type="button"
            className={"item" + (view === "preferences" ? " active" : "")}
            onClick={onShowPrefs}
          >
            <span className="icon"><Icon name="gear" /></span>
            <span className="label">Preferences</span>
          </button>
        </div>
      )}
    </aside>
  );
}

/* Top-right floating action bar. Used when settingsLocation === "page". */
function PageActions({ view, onShowPrefs }) {
  return (
    <div className="page-actions">
      <button
        type="button"
        className={"item-flat" + (view === "preferences" ? " active" : "")}
        onClick={onShowPrefs}
      >
        <Icon name="gear" size={13} /> Preferences
      </button>
    </div>
  );
}

Object.assign(window, { Sidebar, PageActions });
