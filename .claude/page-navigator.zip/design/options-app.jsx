/* Main app — wires sidebar and main view. */

// Finalized layout/behavior config (was previously exposed via Tweaks panel).
const CONFIG = {
  layout: "card",          // "flat" | "card"
  nav: "inset",            // "sticky" | "inset"
  settings: "header",      // "list" | "header" | "page"
  density: "comfortable",  // "comfortable" | "compact"
  maxWidth: 1080,
};

function App() {
  const [selectedScope, setSelectedScope] = React.useState("global");
  const [view, setView] = React.useState("edit"); // "edit" | "preferences"
  const [editingId, setEditingId] = React.useState(null);
  const [bindings, setBindings] = React.useState(() => structuredClone(window.sampleBindings));
  const [timeoutMs, setTimeoutMs] = React.useState(1000);
  const [showDisabled, setShowDisabled] = React.useState(true);

  function selectScope(s) {
    setSelectedScope(s);
    setView("edit");
    setEditingId(null);
  }
  function showPrefs() {
    setView("preferences");
  }
  function toggleEnabled(id) {
    setBindings((prev) => {
      const next = { ...prev };
      next[selectedScope] = prev[selectedScope].map((b) =>
        b.id === id ? { ...b, enabled: !b.enabled } : b,
      );
      return next;
    });
  }

  const mainClass = "main layout-" + CONFIG.layout;
  const cssVars = { "--content-max": CONFIG.maxWidth + "px" };
  const currentBindings = bindings[selectedScope] ?? [];
  const appClass = "app" + (CONFIG.nav === "inset" ? " nav-inset" : "");

  const navProps = {
    selectedScope, view,
    onSelectScope: selectScope,
    onShowPrefs: showPrefs,
    onShowImport: () => {},
    onShowExport: () => {},
    settingsLocation: CONFIG.settings,
  };

  return (
    <div className={appClass} style={cssVars}>
      <Sidebar {...navProps} />
      <main className={mainClass}>
        {CONFIG.settings === "page" && <PageActions view={view} onShowPrefs={showPrefs} />}
        <div className="container">
          <div className={CONFIG.layout === "card" ? "card" : ""}>
            {view === "edit" ? (
              <BindingsView
                scope={selectedScope}
                enableMode="badge"
                density={CONFIG.density}
                showDisabled={showDisabled}
                onToggleShowDisabled={() => setShowDisabled((v) => !v)}
                editingId={editingId}
                onStartEdit={(id) => setEditingId(id)}
                onCancelEdit={() => setEditingId(null)}
                bindings={currentBindings}
                onToggleEnabled={toggleEnabled}
              />
            ) : (
              <PreferencesView timeoutMs={timeoutMs} onChangeTimeout={setTimeoutMs} />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
